package CONTROLADOR;

import DAO.FormacionDao;
import MODELO.Formacion;
import java.io.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class FormacionController extends HttpServlet {

    String FORMS = "formacion.jsp"; // Página a la que se redirige por defecto
    String EDITAR = "formacionEditar.jsp"; // Página para editar registros
    String acceso, action;
    Boolean respuesta;

    FormacionDao dao = new FormacionDao();
    Formacion formacion = new Formacion();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        action = request.getParameter("accion"); // Obtener el parámetro "accion" de la solicitud

        switch (action) {
            case "registros":
                acceso = FORMS; // Si la acción es "registros", redirige a la página de registros
                break;
            case "editar":
                request.setAttribute("idFormacion", request.getParameter("idFormacion")); // Configurar un atributo en la solicitud para el ID de Formacion
                acceso = EDITAR; // Redirige a la página de edición
                break;
            case "eliminar":
                respuesta = dao.deleteById(Integer.parseInt(request.getParameter("idFormacion"))); // Eliminar registro por ID

                if (respuesta == true) {
                    request.setAttribute("msj", "Registro eliminado con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo eliminar el registro"); // Configurar mensaje de error en la solicitud
                }
                acceso = FORMS; // Redirige a la página de registros
                break;
            default:
                acceso = FORMS; // Por defecto, redirige a la página de registros
        }
        RequestDispatcher view = request.getRequestDispatcher(acceso); // Obtener el despachador de solicitud para la página de acceso
        view.forward(request, response); // Reenviar la solicitud y la respuesta al recurso especificado
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        action = request.getParameter("accion"); // Obtener el parámetro "accion" de la solicitud

        switch (action) {
            case "guardar":
                formacion = new Formacion(
                        Integer.parseInt(request.getParameter("id_cedula")),
                        request.getParameter("form_nivelinstruccion"),
                        request.getParameter("form_nrocersenecyt"),
                        request.getParameter("form_institucioneducativa"),
                        request.getParameter("form_añosaprovados"),
                        request.getParameter("form_areaconocimiento"),
                        request.getParameter("form_egresado_graduado"),
                        request.getParameter("form_titulobtenido"),
                        request.getParameter("form_pais")
                );
                respuesta = dao.save(formacion); // Guardar nueva Formacion en la base de datos

                if (respuesta == true) {
                    request.setAttribute("msj", "Registro guardado con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo guardar el registro"); // Configurar mensaje de error en la solicitud
                }
                acceso = FORMS; // Redirige a la página de registros
                break;
            case "actualizar":
                formacion = new Formacion(
                        Integer.parseInt(request.getParameter("idFormacion")),
                        Integer.parseInt(request.getParameter("id_cedula")),
                        request.getParameter("form_nivelinstruccion"),
                        request.getParameter("form_nrocersenecyt"),
                        request.getParameter("form_institucioneducativa"),
                        request.getParameter("form_añosaprovados"),
                        request.getParameter("form_areaconocimiento"),
                        request.getParameter("form_egresado_graduado"),
                        request.getParameter("form_titulobtenido"),
                        request.getParameter("form_pais")
                );

                respuesta = dao.update(formacion); // Actualizar Formacion en la base de datos

                if (respuesta == true) {
                    request.setAttribute("msj", "Cambios guardados con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo guardar los cambios"); // Configurar mensaje de error en la solicitud
                }
                acceso = FORMS; // Redirige a la página de registros
                break;
            default:
                acceso = FORMS; // Por defecto, redirige a la página de registros
        }
        RequestDispatcher view = request.getRequestDispatcher(acceso); // Obtener el despachador de solicitud para la página de acceso
        view.forward(request, response); // Reenviar la solicitud y la respuesta al recurso especificado
    }
}
