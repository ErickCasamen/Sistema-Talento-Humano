package CONTROLADOR;

import DAO.AsistenciaDao;
import MODELO.Asistencia;
import java.io.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class AsistenciaController extends HttpServlet {

    String ASISTENCIAS = "asistencia.jsp"; // Página a la que se redirige por defecto
    String EDITAR = "asistenciaEditar.jsp"; // Página para editar registros
    String acceso, action;
    Boolean respuesta;

    AsistenciaDao dao = new AsistenciaDao();
    Asistencia asistencia = new Asistencia();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        action = request.getParameter("accion"); // Obtener el parámetro "accion" de la solicitud

        switch (action) {
            case "registros":
                acceso = ASISTENCIAS; // Si la acción es "registros", redirige a la página de registros
                break;
            case "editar":
                request.setAttribute("idAsistencia", request.getParameter("idAsistencia")); // Configurar un atributo en la solicitud para el ID de Asistencia
                acceso = EDITAR; // Redirige a la página de edición
                break;
            case "eliminar":
                respuesta = dao.deleteById(Integer.parseInt(request.getParameter("idAsistencia"))); // Eliminar registro por ID

                if (respuesta == true) {
                    request.setAttribute("msj", "Registro eliminado con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo eliminar el registro"); // Configurar mensaje de error en la solicitud
                }
                acceso = ASISTENCIAS; // Redirige a la página de registros
                break;
            default:
                acceso = ASISTENCIAS; // Por defecto, redirige a la página de registros
        }
        RequestDispatcher view = request.getRequestDispatcher(acceso); // Obtener el despachador de solicitud para la página de acceso
        view.forward(request, response); // Reenviar la solicitud y la respuesta al recurso especificado
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        action = request.getParameter("accion"); // Obtener el parámetro "accion" de la solicitud

        switch (action) {
            case "guardar":
                asistencia = new Asistencia(
                        Integer.parseInt(request.getParameter("id_cedula")),
                        request.getParameter("asis_nombredocente"),
                        request.getParameter("asis_cargo"),
                        request.getParameter("asis_fecha"),
                        request.getParameter("asis_horaentrada"),
                        request.getParameter("asis_horasalida"),
                        request.getParameter("asis_observacion")
                );
                respuesta = dao.save(asistencia); // Guardar nueva Asistencia en la base de datos

                if (respuesta == true) {
                    request.setAttribute("msj", "Registro guardado con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo guardar el registro"); // Configurar mensaje de error en la solicitud
                }
                acceso = ASISTENCIAS; // Redirige a la página de registros
                break;
            case "actualizar":
                asistencia = new Asistencia(
                        Integer.parseInt(request.getParameter("idAsistencia")),
                        Integer.parseInt(request.getParameter("id_cedula")),
                        request.getParameter("asis_nombredocente"),
                        request.getParameter("asis_cargo"),
                        request.getParameter("asis_fecha"),
                        request.getParameter("asis_horaentrada"),
                        request.getParameter("asis_horasalida"),
                        request.getParameter("asis_observacion")
                );

                respuesta = dao.update(asistencia); // Actualizar Asistencia en la base de datos

                if (respuesta == true) {
                    request.setAttribute("msj", "Cambios guardados con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo guardar los cambios"); // Configurar mensaje de error en la solicitud
                }
                acceso = ASISTENCIAS; // Redirige a la página de registros
                break;
            default:
                acceso = ASISTENCIAS; // Por defecto, redirige a la página de registros
        }
        RequestDispatcher view = request.getRequestDispatcher(acceso); // Obtener el despachador de solicitud para la página de acceso
        view.forward(request, response); // Reenviar la solicitud y la respuesta al recurso especificado
    }
}
