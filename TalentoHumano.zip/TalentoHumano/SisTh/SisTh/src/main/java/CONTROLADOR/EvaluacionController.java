package CONTROLADOR;

import DAO.EvaluacionDao;
import MODELO.Evaluacion;
import java.io.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class EvaluacionController extends HttpServlet {

    String EVALUACIONES = "evaluacion.jsp"; // Página a la que se redirige por defecto
    String EDITAR = "evaluacionEditar.jsp"; // Página para editar registros
    String acceso, action;
    Boolean respuesta;

    EvaluacionDao dao = new EvaluacionDao();
    Evaluacion evaluacion = new Evaluacion();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        action = request.getParameter("accion"); // Obtener el parámetro "accion" de la solicitud

        switch (action) {
            case "registros":
                acceso = EVALUACIONES; // Si la acción es "registros", redirige a la página de registros
                break;
            case "editar":
                request.setAttribute("idEvaluacion", request.getParameter("idEvaluacion")); // Configurar un atributo en la solicitud para el ID de Evaluacion
                acceso = EDITAR; // Redirige a la página de edición
                break;
            case "eliminar":
                respuesta = dao.deleteById(Integer.parseInt(request.getParameter("idEvaluacion"))); // Eliminar registro por ID

                if (respuesta == true) {
                    request.setAttribute("msj", "Registro eliminado con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo eliminar el registro"); // Configurar mensaje de error en la solicitud
                }
                acceso = EVALUACIONES; // Redirige a la página de registros
                break;
            default:
                acceso = EVALUACIONES; // Por defecto, redirige a la página de registros
        }
        RequestDispatcher view = request.getRequestDispatcher(acceso); // Obtener el despachador de solicitud para la página de acceso
        view.forward(request, response); // Reenviar la solicitud y la respuesta al recurso especificado
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        action = request.getParameter("accion"); // Obtener el parámetro "accion" de la solicitud

        switch (action) {
            case "guardar":
                evaluacion = new Evaluacion(
                        Integer.parseInt(request.getParameter("id_cedula")),
                        request.getParameter("eva_periodoinicio"),
                        request.getParameter("eva_periodohasta"),
                        request.getParameter("eva_nombre"),
                        request.getParameter("eva_puntaje"),
                        request.getParameter("eva_calificacion"),
                        request.getParameter("eva_observacion")
                );
                respuesta = dao.save(evaluacion); // Guardar nueva Evaluacion en la base de datos

                if (respuesta == true) {
                    request.setAttribute("msj", "Registro guardado con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo guardar el registro"); // Configurar mensaje de error en la solicitud
                }
                acceso = EVALUACIONES; // Redirige a la página de registros
                break;
            case "actualizar":
                evaluacion = new Evaluacion(
                        Integer.parseInt(request.getParameter("idEvaluacion")),
                        Integer.parseInt(request.getParameter("id_cedula")),
                        request.getParameter("eva_periodoinicio"),
                        request.getParameter("eva_periodohasta"),
                        request.getParameter("eva_nombre"),
                        request.getParameter("eva_puntaje"),
                        request.getParameter("eva_calificacion"),
                        request.getParameter("eva_observacion")
                );

                respuesta = dao.update(evaluacion); // Actualizar Evaluacion en la base de datos

                if (respuesta == true) {
                    request.setAttribute("msj", "Cambios guardados con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo guardar los cambios"); // Configurar mensaje de error en la solicitud
                }
                acceso = EVALUACIONES; // Redirige a la página de registros
                break;
            default:
                acceso = EVALUACIONES; // Por defecto, redirige a la página de registros
        }
        RequestDispatcher view = request.getRequestDispatcher(acceso); // Obtener el despachador de solicitud para la página de acceso
        view.forward(request, response); // Reenviar la solicitud y la respuesta al recurso especificado
    }
}
