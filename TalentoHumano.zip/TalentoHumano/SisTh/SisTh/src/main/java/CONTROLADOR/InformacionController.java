package CONTROLADOR;

import DAO.InformacionDao;
import MODELO.Informacion;
import java.io.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class InformacionController extends HttpServlet {

    String FORMS = "informacion.jsp"; // Página a la que se redirige por defecto
    String EDITAR = "informacionEditar.jsp"; // Página para editar registros
    String acceso, action;
    Boolean respuesta;

    InformacionDao dao = new InformacionDao();
    Informacion informacion = new Informacion();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        action = request.getParameter("accion"); // Obtener el parámetro "accion" de la solicitud

        switch (action) {
            case "registros":
                acceso = FORMS; // Si la acción es "registros", redirige a la página de registros
                break;
            case "editar":
                request.setAttribute("idInformacion", request.getParameter("idInformacion")); // Configurar un atributo en la solicitud para el ID de Informacion
                acceso = EDITAR; // Redirige a la página de edición
                break;
            case "eliminar":
                respuesta = dao.deleteById(Integer.parseInt(request.getParameter("idInformacion"))); // Eliminar registro por ID

                if (respuesta == true) {
                    request.setAttribute("msj", "Registro eliminado con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo eliminar el registro"); // Configurar mensaje de error en la solicitud
                }
                acceso = FORMS; // Redirige a la página de registros
                break;
            default:
                acceso = FORMS; // Por defecto, redirige a la página de registros
        }
        RequestDispatcher view = request.getRequestDispatcher(acceso); // Obtener el despachador de solicitud para la página de acceso
        view.forward(request, response); // Reenviar la solicitud y la respuesta al recurso especificado
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        action = request.getParameter("accion"); // Obtener el parámetro "accion" de la solicitud

        switch (action) {
            case "guardar":
                informacion = new Informacion(
                        Integer.parseInt(request.getParameter("id_cedula")),
                        request.getParameter("inf_insfinanciera"),
                        request.getParameter("inf_tipocuenta"),
                        request.getParameter("inf_nrocuenta")
                );
                respuesta = dao.save(informacion); // Guardar nueva Informacion en la base de datos

                if (respuesta == true) {
                    request.setAttribute("msj", "Registro guardado con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo guardar el registro"); // Configurar mensaje de error en la solicitud
                }
                acceso = FORMS; // Redirige a la página de registros
                break;
            case "actualizar":
                informacion = new Informacion(
                        Integer.parseInt(request.getParameter("idInformacion")),
                        Integer.parseInt(request.getParameter("id_cedula")),
                        request.getParameter("inf_insfinanciera"),
                        request.getParameter("inf_tipocuenta"),
                        request.getParameter("inf_nrocuenta")
                );

                respuesta = dao.update(informacion); // Actualizar Informacion en la base de datos

                if (respuesta == true) {
                    request.setAttribute("msj", "Cambios guardados con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo guardar los cambios"); // Configurar mensaje de error en la solicitud
                }
                acceso = FORMS; // Redirige a la página de registros
                break;
            default:
                acceso = FORMS; // Por defecto, redirige a la página de registros
        }
        RequestDispatcher view = request.getRequestDispatcher(acceso); // Obtener el despachador de solicitud para la página de acceso
        view.forward(request, response); // Reenviar la solicitud y la respuesta al recurso especificado
    }
}
