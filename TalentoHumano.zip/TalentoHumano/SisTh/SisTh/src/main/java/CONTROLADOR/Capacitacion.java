package CONTROLADOR;

import DAO.CapacitacionDao;
import MODELO.capacitacion;
import java.io.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class Capacitacion extends HttpServlet {

    String FORMS = "capacitaciones.jsp"; // Página a la que se redirige por defecto
    String EDITAR = "capacitacionActualizar.jsp"; // Página para editar registros
    String acceso, action;
    Boolean respuesta;

    capacitacion cap = new capacitacion(); // Objeto para manejar los datos de la capacitación
    CapacitacionDao dao = new CapacitacionDao(); // Inicializar el objeto dao para acceder a la base de datos

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        action = request.getParameter("accion"); // Obtener el parámetro "accion" de la solicitud

        switch (action) {
            case "registros":
                acceso = FORMS; // Si la acción es "registros", redirige a la página de registros
                break;
            case "editar":
                request.setAttribute("idCapacitacion", request.getParameter("idCapacitacion")); // Configurar un atributo en la solicitud para el ID de capacitación
                acceso = EDITAR; // Redirige a la página de edición
                break;
            case "eliminar":
                respuesta = dao.deleteById(Integer.parseInt(request.getParameter("idCapacitacion"))); // Eliminar registro por ID

                if (respuesta == true) {
                    request.setAttribute("msj", "Registro eliminado con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo eliminar el registro"); // Configurar mensaje de error en la solicitud
                }
                acceso = FORMS; // Redirige a la página de registros
                break;
            default:
                acceso = FORMS; // Por defecto, redirige a la página de registros
        }
        RequestDispatcher view = request.getRequestDispatcher(acceso); // Obtener el despachador de solicitud para la página de acceso
        view.forward(request, response); // Reenviar la solicitud y la respuesta al recurso especificado
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        action = request.getParameter("accion"); // Obtener el parámetro "accion" de la solicitud

        switch (action) {
            case "guardar":
                cap = new capacitacion(
                        Integer.parseInt(request.getParameter("id_cedula")),
                        request.getParameter("cap_nombreevento"),
                        request.getParameter("cap_tipo"),
                        request.getParameter("cap_auspiciante"),
                        request.getParameter("cap_horas"),
                        request.getParameter("cap_tipocertificado"),
                        request.getParameter("cap_institucion"),
                        request.getParameter("cap_fechainicio"),
                        request.getParameter("cap_fechafinal"));

                respuesta = dao.save(cap); // Guardar nueva capacitación en la base de datos

                if (respuesta == true) {
                    request.setAttribute("msj", "Registro guardado con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo guardar el registro"); // Configurar mensaje de error en la solicitud
                }
                acceso = FORMS; // Redirige a la página de registros
                break;
            case "actualizar":
                cap = new capacitacion(
                        Integer.parseInt(request.getParameter("idCapacitacion")),
                        Integer.parseInt(request.getParameter("id_cedula")),
                        request.getParameter("cap_nombreevento"),
                        request.getParameter("cap_tipo"),
                        request.getParameter("cap_auspiciante"),
                        request.getParameter("cap_horas"),
                        request.getParameter("cap_tipocertificado"),
                        request.getParameter("cap_institucion"),
                        request.getParameter("cap_fechainicio"),
                        request.getParameter("cap_fechafinal"));

                respuesta = dao.update(cap); // Actualizar capacitación en la base de datos

                if (respuesta == true) {
                    request.setAttribute("msj", "Cambios guardados con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo guardar los cambios"); // Configurar mensaje de error en la solicitud
                }
                acceso = FORMS; // Redirige a la página de registros
                break;
            default:
                acceso = FORMS; // Por defecto, redirige a la página de registros
        }
        RequestDispatcher view = request.getRequestDispatcher(acceso); // Obtener el despachador de solicitud para la página de acceso
        view.forward(request, response); // Reenviar la solicitud y la respuesta al recurso especificado
    }
}
