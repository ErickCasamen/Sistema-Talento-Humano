package CONTROLADOR;

import DAO.*;
import MODELO.Permiso;
import java.io.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class PermisoController extends HttpServlet {

    String FORMS = "permiso.jsp"; // Página a la que se redirige por defecto
    String EDITAR = "permisoEditar.jsp"; // Página para editar registros
    String acceso, action;
    Boolean respuesta;

    PermisosDao dao = new PermisosDao();
    Permiso permiso = new Permiso();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        action = request.getParameter("accion"); // Obtener el parámetro "accion" de la solicitud

        switch (action) {
            case "registros":
                acceso = FORMS; // Si la acción es "registros", redirige a la página de registros
                break;
            case "editar":
                request.setAttribute("idPermiso", request.getParameter("idPermiso")); // Configurar un atributo en la solicitud para el ID de Permiso
                acceso = EDITAR; // Redirige a la página de edición
                break;
            case "eliminar":
                respuesta = dao.deleteById(Integer.parseInt(request.getParameter("idPermiso"))); // Eliminar registro por ID

                if (respuesta == true) {
                    request.setAttribute("msj", "Registro eliminado con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo eliminar el registro"); // Configurar mensaje de error en la solicitud
                }
                acceso = FORMS; // Redirige a la página de registros
                break;
            default:
                acceso = FORMS; // Por defecto, redirige a la página de registros
        }
        RequestDispatcher view = request.getRequestDispatcher(acceso); // Obtener el despachador de solicitud para la página de acceso
        view.forward(request, response); // Reenviar la solicitud y la respuesta al recurso especificado
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        action = request.getParameter("accion"); // Obtener el parámetro "accion" de la solicitud

        switch (action) {
            case "guardar":
                permiso = new Permiso(
                        Integer.parseInt(request.getParameter("id_cedula")),
                        request.getParameter("per_fecha"),
                        request.getParameter("per_provincia"),
                        request.getParameter("per_regimen"),
                        request.getParameter("per_Apellidos"),
                        request.getParameter("per_Nombres"),
                        request.getParameter("per_cedula"),
                        request.getParameter("per_cordinacionzonal"),
                        request.getParameter("per_direccionunidad"),
                        request.getParameter("per_motivo"),
                        request.getParameter("per_horas"),
                        request.getParameter("per_dias"),
                        request.getParameter("per_valordescontar")
                );
                respuesta = dao.save(permiso); // Guardar nuevo Permiso en la base de datos

                if (respuesta == true) {
                    request.setAttribute("msj", "Registro guardado con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo guardar el registro"); // Configurar mensaje de error en la solicitud
                }
                acceso = FORMS; // Redirige a la página de registros
                break;
            case "actualizar":
                permiso = new Permiso(
                        Integer.parseInt(request.getParameter("idPermiso")),
                        Integer.parseInt(request.getParameter("id_cedula")),
                        request.getParameter("per_fecha"),
                        request.getParameter("per_provincia"),
                        request.getParameter("per_regimen"),
                        request.getParameter("per_Apellidos"),
                        request.getParameter("per_Nombres"),
                        request.getParameter("per_cedula"),
                        request.getParameter("per_cordinacionzonal"),
                        request.getParameter("per_direccionunidad"),
                        request.getParameter("per_motivo"),
                        request.getParameter("per_horas"),
                        request.getParameter("per_dias"),
                        request.getParameter("per_valordescontar")
                );

                respuesta = dao.update(permiso); // Actualizar Permiso en la base de datos

                if (respuesta == true) {
                    request.setAttribute("msj", "Cambios guardados con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo guardar los cambios"); // Configurar mensaje de error en la solicitud
                }
                acceso = FORMS; // Redirige a la página de registros
                break;
            default:
                acceso = FORMS; // Por defecto, redirige a la página de registros
        }
        RequestDispatcher view = request.getRequestDispatcher(acceso); // Obtener el despachador de solicitud para la página de acceso
        view.forward(request, response); // Reenviar la solicitud y la respuesta al recurso especificado
    }
}
