package CONTROLADOR;

import DAO.HijoDao;
import MODELO.Hijo;
import java.io.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

/**
 *
 * @author HP
 */
@WebServlet(name = "Hijos", urlPatterns = {"/Hijos"})
public class Hijos extends HttpServlet {

    String FORMS = "hijos.jsp"; // Página a la que se redirige por defecto
    String EDITAR = "hijosActualizar.jsp"; // Página para editar registros
    String acceso, action;
    Boolean respuesta;

    Hijo hij = new Hijo(); // Objeto para manejar los datos de la capacitación
    HijoDao dao = new HijoDao(); // Inicializar el objeto dao para acceder a la base de datos

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        action = request.getParameter("accion"); // Obtener el parámetro "accion" de la solicitud

        switch (action) {
            case "registros":
                acceso = FORMS; // Si la acción es "registros", redirige a la página de registros
                break;
            case "editar":
                request.setAttribute("idHIJOS", request.getParameter("idHIJOS")); // Configurar un atributo en la solicitud para el ID de Hijo
                acceso = EDITAR; // Redirige a la página de edición
                break;
            case "eliminar":
                respuesta = dao.deleteById(Integer.parseInt(request.getParameter("idHIJOS"))); // Eliminar registro por ID

                if (respuesta == true) {
                    request.setAttribute("msj", "Registro eliminado con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo eliminar el registro"); // Configurar mensaje de error en la solicitud
                }
                acceso = FORMS; // Redirige a la página de registros
                break;
            default:
                acceso = FORMS; // Por defecto, redirige a la página de registros
        }
        RequestDispatcher view = request.getRequestDispatcher(acceso); // Obtener el despachador de solicitud para la página de acceso
        view.forward(request, response); // Reenviar la solicitud y la respuesta al recurso especificado
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        action = request.getParameter("accion"); // Obtener el parámetro "accion" de la solicitud

        switch (action) {
            case "guardar":
                hij = new Hijo(
                        Integer.parseInt(request.getParameter("id_cedula")),
                        request.getParameter("hi_cedula"),
                        request.getParameter("hi_nombres"),
                        request.getParameter("hi_apellidos"),
                        request.getParameter("hi_nivelinstitucional"));
                respuesta = dao.save(hij); // Guardar nueva capacitación en la base de datos

                if (respuesta == true) {
                    request.setAttribute("msj", "Registro guardado con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo guardar el registro"); // Configurar mensaje de error en la solicitud
                }
                acceso = FORMS; // Redirige a la página de registros
                break;
            case "actualizar":
                hij = new Hijo(
                       Integer.parseInt(request.getParameter("id_cedula")),
                        request.getParameter("hi_cedula"),
                        request.getParameter("hi_nombres"),
                        request.getParameter("hi_apellidos"),
                        request.getParameter("hi_nivelinstitucional"));

                respuesta = dao.update(hij); // Actualizar capacitación en la base de datos

                if (respuesta == true) {
                    request.setAttribute("msj", "Cambios guardados con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo guardar los cambios"); // Configurar mensaje de error en la solicitud
                }
                acceso = FORMS; // Redirige a la página de registros
                break;
            default:
                acceso = FORMS; // Por defecto, redirige a la página de registros
        }
        RequestDispatcher view = request.getRequestDispatcher(acceso); // Obtener el despachador de solicitud para la página de acceso
        view.forward(request, response); // Reenviar la solicitud y la respuesta al recurso especificado
    }
}
