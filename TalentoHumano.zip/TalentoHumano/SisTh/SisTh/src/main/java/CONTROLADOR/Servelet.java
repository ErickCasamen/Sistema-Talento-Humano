package CONTROLADOR;

import DAO.LoginDAO;
import DAO.CapacitacionDao;
import DAO.DocentesDao;
import MODELO.Login;
import MODELO.capacitacion;
import MODELO.Docente;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "Servlet", urlPatterns = {"/Servlet"})
public class Servelet extends HttpServlet {

    LoginDAO test;
    String mensaje;
    DocentesDao docDao;
    CapacitacionDao capDao;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setAttribute("cajitamensajebd", mensaje);

        // Borrar el atributo después de mostrarlo
        request.removeAttribute("cajitamensajebd");

        request.getRequestDispatcher("index.jsp").forward(request, response);
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String enteredUsername = request.getParameter("username");
        String enteredPassword = request.getParameter("password");

        HttpSession session = request.getSession();
        Login login = (Login) session.getAttribute("login");

        if (login == null) {
            login = new Login();
            session.setAttribute("login", login);
        }

        boolean validacion = login.validarUsuario(enteredUsername, enteredPassword);

        if (validacion) {
            login.resetAttempts();
            response.sendRedirect("Menu.jsp");
            return;
        } else {
            int remainingAttempts = login.getRemainingAttempts();

            if (remainingAttempts > 0) {
                request.setAttribute("loginAttempts", "Te quedan: " + remainingAttempts + " intentos");
            } else {
                request.setAttribute("loginAttempts", "!Su Cuenta esta bloqueada.");
                login.resetAttempts();
            }
            request.setAttribute("cajitamensajebd", mensaje);
            request.getRequestDispatcher("index.jsp").forward(request, response);

        }

        try {
            
            List<Docente> lista = docDao.getAll();
            System.out.println("ESTA ES LA LISTA DE DOCENTES" + lista);
            System.out.println("");
            
        } catch (Exception e) {
            System.out.println("ERROR AL LISTAR LOS DATOS " + e.getMessage() + " " + e.getCause());
        }
        try {
            
            List<capacitacion> lista = capDao.getAll();
            System.out.println("ESTA ES LA LISTA DE CAPACITACIONES" + lista);
            System.out.println("");
            
        } catch (Exception e) {
            System.out.println("ERROR AL LISTAR LOS DATOS " + e.getMessage() + " " + e.getCause());
        }

        processRequest(request, response);

    }

    @Override
    public void init() throws ServletException {
        String jdbcURL = getServletContext().getInitParameter("jdbcURL");
        String jdbcUserName = getServletContext().getInitParameter("jdbcUserName");
        String jdbcPassword = getServletContext().getInitParameter("jdbcPassword");

        try {
            test = new LoginDAO(jdbcURL, jdbcUserName, jdbcPassword);
            mensaje = "Conexion exitosa";
        } catch (SQLException ex) {
            Logger.getLogger(Servelet.class.getName()).log(Level.SEVERE, null, ex);
            mensaje = "Problema de Servicio";
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
