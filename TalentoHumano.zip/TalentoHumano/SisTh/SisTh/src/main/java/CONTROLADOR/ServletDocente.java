package CONTROLADOR;

import DAO.DocentesDao;
import MODELO.Docente;
import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "ServletDocente", urlPatterns = {"/ServletDocente"})
public class ServletDocente extends HttpServlet {

    // Variable de tipo global
    DocentesDao dao = new DocentesDao();
    String mensaje;

    String FORM = "docentes.jsp";
    String EDITAR = "docenteEditar.jsp";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("accion");
        String acceso = "";

        switch (action) {

            case "editar":
                request.setAttribute("idDocente", request.getParameter("idDocente"));
                acceso = EDITAR;
                break;
            case "eliminar":
                boolean respuesta = dao.deleteById(Integer.parseInt(request.getParameter("idDocente")));
                if (respuesta) {
                    mensaje = "registro eliminado correctamente";
                } else {
                    mensaje = "Error al eliminar el registro";
                }
                acceso = EDITAR;
                break;
            default:
                acceso = FORM;
        }
        RequestDispatcher view = request.getRequestDispatcher(acceso);
        view.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String re = request.getParameter("docentes");

        if (re.equalsIgnoreCase("Registrar")) {
            int ced = Integer.parseInt(request.getParameter("cedula"));
            String nom = request.getParameter("nombres");
            String ape = request.getParameter("apellidos");
            String nac = request.getParameter("nacionalidad");
            String fena = request.getParameter("fecha_nacimiento");
            String dir = request.getParameter("direccion");
            String pro = request.getParameter("provincia");
            String tipe = request.getParameter("etnia");
            String tipg = request.getParameter("genero");
            String est = request.getParameter("estado_civil");
            String tips = request.getParameter("tipo_sangre");
            String celu = request.getParameter("telefono_celular");
            String tel = request.getParameter("telefono_convencional");
            String corr = request.getParameter("correo");
            String ant = request.getParameter("antecedente_publico");
            String dec = request.getParameter("declaracion_bienes");
            String tipu = request.getParameter("tipo_usuario");
            String usu = request.getParameter("usuario");
            String con = request.getParameter("contraseña");

            Docente docente = new Docente(ced, nom, ape, nac, fena, dir, pro, tipe, tipg, est, tips, celu, tel, corr, ant, dec, tipu, usu, con);
            boolean respuesta = dao.save(docente);

            if (respuesta) {
                mensaje = "Datos Insertados Correctamente";
            } else {
                mensaje = "Error en la Inserción de datos";
            }
        } else if (re.equalsIgnoreCase("Actualizar")) {
            int idDocente = Integer.parseInt(request.getParameter("id_cedula"));
            String nom = request.getParameter("nombres");
            String ape = request.getParameter("apellidos");
            String nac = request.getParameter("nacionalidad");
            String fena = request.getParameter("fecha_nacimiento");
            String dir = request.getParameter("direccion");
            String pro = request.getParameter("provincia");
            String tipe = request.getParameter("etnia");
            String tipg = request.getParameter("genero");
            String est = request.getParameter("estado_civil");
            String tips = request.getParameter("tipo_sangre");
            String celu = request.getParameter("telefono_celular");
            String tel = request.getParameter("telefono_convencional");
            String corr = request.getParameter("correo");
            String ant = request.getParameter("antecedente_publico");
            String dec = request.getParameter("declaracion_bienes");
            String tipu = request.getParameter("tipo_usuario");
            String usu = request.getParameter("usuario");
            String con = request.getParameter("contraseña");

            Docente docente = new Docente(idDocente, nom, ape, nac, fena, dir, pro, tipe, tipg, est, tips, celu, tel, corr, ant, dec, tipu, usu, con);
            boolean respuesta = dao.update(docente);

            if (respuesta) {
                mensaje = "Datos Actualizados Correctamente";
            } else {
                mensaje = "Error en la Actualización de datos";
            }
        }
        // Zona devolución de datos
        request.setAttribute("msj", mensaje);
        RequestDispatcher objdevuelve = request.getRequestDispatcher(FORM);

        objdevuelve.forward(request, response);
    }
}
