package CONTROLADOR;

import DAO.InclusionDao;
import MODELO.Inclusion;
import java.io.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class InclusionController extends HttpServlet {

    String FORMS = "inclusion.jsp"; // Página a la que se redirige por defecto
    String EDITAR = "inclusionEditar.jsp"; // Página para editar registros
    String acceso, action;
    Boolean respuesta;

    InclusionDao dao = new InclusionDao();
    Inclusion inclusion = new Inclusion();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        action = request.getParameter("accion"); // Obtener el parámetro "accion" de la solicitud

        switch (action) {
            case "registros":
                acceso = FORMS; // Si la acción es "registros", redirige a la página de registros
                break;
            case "editar":
                request.setAttribute("idInclusion", request.getParameter("idInclusion")); // Configurar un atributo en la solicitud para el ID de Inclusion
                acceso = EDITAR; // Redirige a la página de edición
                break;
            case "eliminar":
                respuesta = dao.deleteById(Integer.parseInt(request.getParameter("idInclusion"))); // Eliminar registro por ID

                if (respuesta == true) {
                    request.setAttribute("msj", "Registro eliminado con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo eliminar el registro"); // Configurar mensaje de error en la solicitud
                }
                acceso = FORMS; // Redirige a la página de registros
                break;
            default:
                acceso = FORMS; // Por defecto, redirige a la página de registros
        }
        RequestDispatcher view = request.getRequestDispatcher(acceso); // Obtener el despachador de solicitud para la página de acceso
        view.forward(request, response); // Reenviar la solicitud y la respuesta al recurso especificado
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        action = request.getParameter("accion"); // Obtener el parámetro "accion" de la solicitud

        switch (action) {
            case "guardar":
                inclusion = new Inclusion(
                        Integer.parseInt(request.getParameter("id_cedula")),
                        request.getParameter("inc_nacionalidad"),
                        request.getParameter("inc_embarazo"),
                        request.getParameter("inc_mesesembarazo"),
                        request.getParameter("inc_licencia"),
                        request.getParameter("inc_porcentaje")
                );
                respuesta = dao.save(inclusion); // Guardar nueva Inclusion en la base de datos

                if (respuesta == true) {
                    request.setAttribute("msj", "Registro guardado con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo guardar el registro"); // Configurar mensaje de error en la solicitud
                }
                acceso = FORMS; // Redirige a la página de registros
                break;
            case "actualizar":
                inclusion = new Inclusion(
                        Integer.parseInt(request.getParameter("idInclusion")),
                        Integer.parseInt(request.getParameter("id_cedula")),
                        request.getParameter("inc_nacionalidad"),
                        request.getParameter("inc_embarazo"),
                        request.getParameter("inc_mesesembarazo"),
                        request.getParameter("inc_licencia"),
                        request.getParameter("inc_porcentaje")
                );

                respuesta = dao.update(inclusion); // Actualizar Inclusion en la base de datos

                if (respuesta == true) {
                    request.setAttribute("msj", "Cambios guardados con éxito"); // Configurar mensaje de éxito en la solicitud
                } else {
                    request.setAttribute("msj", "No se pudo guardar los cambios"); // Configurar mensaje de error en la solicitud
                }
                acceso = FORMS; // Redirige a la página de registros
                break;
            default:
                acceso = FORMS; // Por defecto, redirige a la página de registros
        }
        RequestDispatcher view = request.getRequestDispatcher(acceso); // Obtener el despachador de solicitud para la página de acceso
        view.forward(request, response); // Reenviar la solicitud y la respuesta al recurso especificado
    }
}
