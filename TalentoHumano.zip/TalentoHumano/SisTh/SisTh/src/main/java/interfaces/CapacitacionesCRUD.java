package interfaces;

import MODELO.capacitacion;
import java.util.List;

public interface CapacitacionesCRUD {

    List<capacitacion> getAll();

    capacitacion getByIdCapacitacion(Integer idDocente);

    Boolean save(capacitacion capacitacion);

    Boolean update(capacitacion capacitacion);

    Boolean deleteById(Integer idCapacitacion);

}
