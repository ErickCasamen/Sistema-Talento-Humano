
package interfaces;

import MODELO.Discapacidad;
import java.util.List;

public interface DiscapacidadCRUD {
      List<Discapacidad> getAll();
}
