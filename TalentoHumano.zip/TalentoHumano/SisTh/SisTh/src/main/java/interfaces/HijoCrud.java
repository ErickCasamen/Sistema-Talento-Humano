package interfaces;

import MODELO.Hijo;
import java.util.List;

public interface HijoCrud {

    List<Hijo> getAll();

    Hijo getById(Integer idHijo);

    Boolean deleteById(Integer idHijo);

    Boolean save(Hijo hijo);

    Boolean update(Hijo hijo);
    
}
