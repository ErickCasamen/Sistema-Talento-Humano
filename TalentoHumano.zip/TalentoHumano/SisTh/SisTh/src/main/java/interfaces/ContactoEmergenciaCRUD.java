
package interfaces;

import MODELO.Emergencias;
import java.util.List;

public interface ContactoEmergenciaCRUD {
      List<Emergencias> getAll();
}
