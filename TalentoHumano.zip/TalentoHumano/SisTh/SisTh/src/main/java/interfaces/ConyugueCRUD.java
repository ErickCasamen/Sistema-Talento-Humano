package interfaces;

import MODELO.Conyugues;
import java.util.List;

public interface ConyugueCRUD {

    List<Conyugues> getAll();
}
