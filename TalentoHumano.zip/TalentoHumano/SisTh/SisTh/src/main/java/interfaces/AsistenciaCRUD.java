
package interfaces;

import MODELO.Asistencia;
import java.util.List;

public interface AsistenciaCRUD {
        List<Asistencia> getAll();

    Asistencia getById(Integer idHijo);

    Boolean deleteById(Integer idHijo);

    Boolean save(Asistencia hijo);

    Boolean update(Asistencia hijo);
    
}
