
package interfaces;

import MODELO.Formacion;
import java.util.List;

/**
 *
 * @author thony
 */
public interface FormacionCRUD {
    List<Formacion> getAll();
}
