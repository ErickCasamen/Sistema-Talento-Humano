package interfaces;

import MODELO.Docente;
import java.util.List;

public interface DocentesCrud {

    List<Docente> getAll();
    Docente getById(Integer idCedula);
}
