package DAO;

import BD.Conexion;
import MODELO.Docente;
import interfaces.DocentesCrud;
import java.sql.*;
import java.util.ArrayList;

import java.util.List;

public class DocentesDao implements DocentesCrud {

    Docente docente = new Docente();
    Conexion cn = new Conexion();
    CallableStatement cs;
    Connection con;
    ResultSet rs;

    @Override
    public List<Docente> getAll() {
        ArrayList<Docente> lista = new ArrayList<>();
        try {

            con = (Connection) cn.getConexion();
            cs = con.prepareCall("call getAllDocente()");
            rs = cs.executeQuery();
            while (rs.next()) {
                Docente doc = new Docente();
                doc.setId_cedula(rs.getInt(1));
                doc.setDoc_nombres(rs.getString(2));
                doc.setDoc_apellidos(rs.getString(3));
                doc.setDoc_nacionalidad(rs.getString(4));
                doc.setDoc_fechanacimiento(rs.getString(5));
                doc.setDoc_direccion(rs.getString(6));
                doc.setDoc_provincia(rs.getString(7));
                doc.setDoc_tipoetnia(rs.getString(8));
                doc.setDoc_tipogenero(rs.getString(9));
                doc.setDoc_estadocivil(rs.getString(10));
                doc.setDoc_tiposangre(rs.getString(11));
                doc.setDoc_celular(rs.getString(12));
                doc.setDoc_telefono(rs.getString(13));
                doc.setDoc_correo(rs.getString(14));
                doc.setDoc_antservpublico(rs.getString(15));
                doc.setDoc_declaracionbienes(rs.getString(16));
                doc.setDoc_tipousuario(rs.getString(17));
                doc.setDoc_usuario(rs.getString(18));
                doc.setDoc_contraseña(rs.getString(19));

                lista.add(doc);
            }
        } catch (SQLException ex) {
            System.out.println("Error al listar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return lista;
    }

    @Override
    public Docente getById(Integer idCedula) {
        try {
            con = cn.getConexion();
            String query = "SELECT * FROM docente WHERE id_cedula=?";
            cs = con.prepareCall(query);

            // Establecer el valor del parámetro en el PreparedStatement
            cs.setInt(1, idCedula);

            // Ejecutar la consulta
            rs = cs.executeQuery();

            // Verificar si se encontró el registro
            if (rs.next()) {
                docente = new Docente();
                docente.setId_cedula(rs.getInt("id_cedula"));
                docente.setDoc_nombres(rs.getString("doc_nombres"));
                docente.setDoc_apellidos(rs.getString("doc_apellidos"));
                docente.setDoc_nacionalidad(rs.getString("doc_nacionalidad"));
                docente.setDoc_fechanacimiento(rs.getString("doc_fechanacimiento"));
                docente.setDoc_direccion(rs.getString("doc_direccion"));
                docente.setDoc_provincia(rs.getString("doc_provincia"));
                docente.setDoc_tipoetnia(rs.getString("doc_tipoetnia"));
                docente.setDoc_tipogenero(rs.getString("doc_tipogenero"));
                docente.setDoc_estadocivil(rs.getString("doc_estadocivil"));
                docente.setDoc_tiposangre(rs.getString("doc_tiposangre"));
                docente.setDoc_celular(rs.getString("doc_celular"));
                docente.setDoc_telefono(rs.getString("doc_telefono"));
                docente.setDoc_correo(rs.getString("doc_correo"));
                docente.setDoc_antservpublico(rs.getString("doc_antservpublico"));
                docente.setDoc_declaracionbienes(rs.getString("doc_declaracionbienes"));
                docente.setDoc_tipousuario(rs.getString("doc_tipousuario"));
                docente.setDoc_usuario(rs.getString("doc_usuario"));
                docente.setDoc_contraseña(rs.getString("doc_contraseña"));

            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener por ID: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return docente;
    }

    public Boolean update(Docente docente) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "UPDATE docente SET "
                    + "doc_nombres=?, "
                    + "doc_apellidos=?, "
                    + "doc_nacionalidad=?, "
                    + "doc_fechanacimiento=?, "
                    + "doc_direccion=?, "
                    + "doc_provincia=?, "
                    + "doc_tipoetnia=?, "
                    + "doc_tipogenero=?, "
                    + "doc_estadocivil=?, "
                    + "doc_tiposangre=?, "
                    + "doc_celular=?, "
                    + "doc_telefono=?, "
                    + "doc_correo=?, "
                    + "doc_antservpublico=?, "
                    + "doc_declaracionbienes=?, "
                    + "doc_tipousuario=?, "
                    + "doc_usuario=?, "
                    + "doc_contraseña=? "
                    + "WHERE id_cedula=?";
            cs = con.prepareCall(query);

            // Establecer valores de parámetros en el PreparedStatement
            cs.setString(1, docente.getDoc_nombres());
            cs.setString(2, docente.getDoc_apellidos());
            cs.setString(3, docente.getDoc_nacionalidad());
            cs.setString(4, docente.getDoc_fechanacimiento());
            cs.setString(5, docente.getDoc_direccion());
            cs.setString(6, docente.getDoc_provincia());
            cs.setString(7, docente.getDoc_tipoetnia());
            cs.setString(8, docente.getDoc_tipogenero());
            cs.setString(9, docente.getDoc_estadocivil());
            cs.setString(10, docente.getDoc_tiposangre());
            cs.setString(11, docente.getDoc_celular());
            cs.setString(12, docente.getDoc_telefono());
            cs.setString(13, docente.getDoc_correo());
            cs.setString(14, docente.getDoc_antservpublico());
            cs.setString(15, docente.getDoc_declaracionbienes());
            cs.setString(16, docente.getDoc_tipousuario());
            cs.setString(17, docente.getDoc_usuario());
            cs.setString(18, docente.getDoc_contraseña());

            // Id_cedula para la cláusula WHERE
            cs.setInt(19, docente.getId_cedula());

            // Ejecutar la actualización
            int rowsAffected = cs.executeUpdate();

            // Verificar si la actualización fue exitosa
            success = (rowsAffected > 0);

        } catch (SQLException ex) {
            System.out.println("Error al actualizar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean save(Docente docente) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "INSERT INTO docente ("
                    + "doc_nombres, doc_apellidos, doc_nacionalidad, doc_fechanacimiento, doc_direccion, doc_provincia, doc_tipoetnia, doc_tipogenero, doc_estadocivil, doc_tiposangre, doc_celular, doc_telefono, doc_correo, doc_antservpublico, doc_declaracionbienes, doc_tipousuario, doc_usuario, doc_contraseña)"
                    + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            cs = con.prepareCall(query);

            // Establecer valores de parámetros en el PreparedStatement
            cs.setString(1, docente.getDoc_nombres());
            cs.setString(2, docente.getDoc_apellidos());
            cs.setString(3, docente.getDoc_nacionalidad());
            cs.setString(4, docente.getDoc_fechanacimiento());
            cs.setString(5, docente.getDoc_direccion());
            cs.setString(6, docente.getDoc_provincia());
            cs.setString(7, docente.getDoc_tipoetnia());
            cs.setString(8, docente.getDoc_tipogenero());
            cs.setString(9, docente.getDoc_estadocivil());
            cs.setString(10, docente.getDoc_tiposangre());
            cs.setString(11, docente.getDoc_celular());
            cs.setString(12, docente.getDoc_telefono());
            cs.setString(13, docente.getDoc_correo());
            cs.setString(14, docente.getDoc_antservpublico());
            cs.setString(15, docente.getDoc_declaracionbienes());
            cs.setString(16, docente.getDoc_tipousuario());
            cs.setString(17, docente.getDoc_usuario());
            cs.setString(18, docente.getDoc_contraseña());

            // Ejecutar la inserción
            int rowsAffected = cs.executeUpdate();

            // Verificar si la inserción fue exitosa
            success = (rowsAffected > 0);

        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean deleteById(Integer idDocente) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "DELETE FROM capacitaciones WHERE id_cedula=?";
            cs = con.prepareCall(query);

            // Establecer el valor del parámetro en el PreparedStatement
            cs.setInt(1, idDocente);

            // Ejecutar la eliminación
            int rowsAffected = cs.executeUpdate();

            // Verificar si la eliminación fue exitosa
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al eliminar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    private void cerrarRecursos() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (cs != null) {
                cs.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            System.out.println("Error al cerrar recursos: " + ex.getMessage());
        }
    }
}
