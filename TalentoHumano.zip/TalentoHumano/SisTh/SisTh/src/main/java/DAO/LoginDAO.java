package DAO;

import BD.ConexionBD;
import java.sql.SQLException;
public class LoginDAO {
   //zona de atributos
private ConexionBD conecta;

//constructor
public  LoginDAO(String jdbcURL, String jdbcUserName, String jdbcPassword) throws SQLException{
    //instancio la claseDB con los parametros para la conexion DB
    conecta = new ConexionBD(jdbcURL, jdbcUserName, jdbcPassword);
    
}

}
