package DAO;

import BD.Conexion;
import MODELO.Emergencias;
import interfaces.ContactoEmergenciaCRUD;
import java.sql.*;
import java.util.*;

public class EmergenciaDao implements ContactoEmergenciaCRUD {

    //Estancias necesarias para la logica
    Emergencias emergencia = new Emergencias();
    Conexion cn = new Conexion();
    CallableStatement cs;
    Connection con;
    ResultSet rs;

    @Override
    public List<Emergencias> getAll() {
        ArrayList<Emergencias> lista = new ArrayList<>();
        try {

            con = (Connection) cn.getConexion();
            cs = con.prepareCall("call getAllContactoEmergencia()");
            rs = cs.executeQuery();
            while (rs.next()) {
                Emergencias emr = new Emergencias();
                emr.setIdEmergencia(rs.getInt(1));
                emr.setIdCedula(rs.getInt(2));
                emr.setContNombres(rs.getString(3));
                emr.setContApellidos(rs.getString(4));
                emr.setContTelefono(rs.getString(5));

                lista.add(emr);
            }
        } catch (SQLException ex) {
            System.out.println("Error al listar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return lista;
    }

    public Emergencias getByIdEmergencia(Integer idEmergencia) {
        Emergencias cli = null;
        try {
            con = cn.getConexion();
            String query = "SELECT * FROM contactoemergencia WHERE idCONTACTOEMERGENCIA=?";
            cs = con.prepareCall(query);

            // Establecer el valor del parámetro en el PreparedStatement
            cs.setInt(1, idEmergencia);

            // Ejecutar la consulta
            rs = cs.executeQuery();

            // Verificar si se encontró el registro
            if (rs.next()) {
                cli = new Emergencias();
                cli.setIdEmergencia(rs.getInt("idCONTACTOEMERGENCIA"));
                cli.setIdCedula(rs.getInt("DOCENTE_id_cedula"));
                cli.setContNombres(rs.getString("cont_nombres"));
                cli.setContApellidos(rs.getString("cont_apellidos"));
                cli.setContTelefono(rs.getString("cont_telefono"));

            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener por ID: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return cli;
    }

    public Boolean save(Emergencias Emergencia) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "INSERT INTO contactoemergencia ("
                    + "DOCENTE_id_cedula,"
                    + "cont_nombres, "
                    + "cont_apellidos, "
                    + "cont_telefono" // Quité la coma adicional aquí
                    + ")"
                    + " VALUES (?, ?, ?, ?)";
            cs = con.prepareCall(query);

            // Establecer valores de parámetros en el PreparedStatement
            cs.setInt(1, Emergencia.getIdCedula());
            cs.setString(2, Emergencia.getContNombres());
            cs.setString(3, Emergencia.getContApellidos());
            cs.setString(4, Emergencia.getContTelefono());

            // Ejecutar la inserción
            int rowsAffected = cs.executeUpdate();

            // Verificar si la inserción fue exitosa
            success = (rowsAffected > 0);

        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean update(Emergencias Emergencia) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "UPDATE contactoemergencia SET "
                    + "DOCENTE_id_cedula=?, "
                    + "cont_nombres=?, "
                    + "cont_apellidos=?, "
                    + "cont_telefono=? "
                    + "WHERE idCONTACTOEMERGENCIA=?";
            cs = con.prepareCall(query);

            // Establecer valores de parámetros en el PreparedStatement
            cs.setInt(1, Emergencia.getIdCedula());
            cs.setString(2, Emergencia.getContNombres());
            cs.setString(3, Emergencia.getContApellidos());
            cs.setString(4, Emergencia.getContTelefono());
            cs.setInt(5, Emergencia.getIdEmergencia());

            // Ejecutar la actualización
            int rowsAffected = cs.executeUpdate();

            // Verificar si la actualización fue exitosa
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al actualizar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean deleteById(Integer id_Emergencia) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "DELETE FROM contactoemergencia WHERE idCONTACTOEMERGENCIA=?";
            cs = con.prepareCall(query);

            // Establecer el valor del parámetro en el PreparedStatement
            cs.setInt(1, id_Emergencia);

            // Ejecutar la eliminación
            int rowsAffected = cs.executeUpdate();

            // Verificar si la eliminación fue exitosa
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al eliminar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    private void cerrarRecursos() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (cs != null) {
                cs.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            System.out.println("Error al cerrar recursos: " + ex.getMessage());
        }
    }

}
