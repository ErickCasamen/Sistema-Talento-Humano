package DAO;

import BD.Conexion;
import MODELO.Formacion;
import interfaces.FormacionCRUD;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FormacionDao implements FormacionCRUD {

    // Estancias necesarias para la lógica
    Conexion cn = new Conexion();
    CallableStatement cs;
    Connection con;
    ResultSet rs;

    @Override
    public List<Formacion> getAll() {
        ArrayList<Formacion> lista = new ArrayList<>();
        try {
            con = cn.getConexion();
            cs = con.prepareCall("call getAllFormacion()");
            rs = cs.executeQuery();
            while (rs.next()) {
                Formacion formacion = new Formacion();
                formacion.setIdFormacion(rs.getInt(1));
                formacion.setId_cedula(rs.getInt(2));
                formacion.setForm_nivelinstruccion(rs.getString(3));
                formacion.setForm_nrocersenecyt(rs.getString(4));
                formacion.setForm_institucioneducativa(rs.getString(5));
                formacion.setForm_añosaprovados(rs.getString(6));
                formacion.setForm_areaconocimiento(rs.getString(7));
                formacion.setForm_egresado_graduado(rs.getString(8));
                formacion.setForm_titulobtenido(rs.getString(9));
                formacion.setForm_pais(rs.getString(10));
                lista.add(formacion);
            }
        } catch (SQLException ex) {
            System.out.println("Error al listar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return lista;
    }

    public Formacion getById(Integer idFormacion) {
        Formacion formacion = null;
        try {
            con = cn.getConexion();
            String query = "SELECT * FROM formacionacademica WHERE idFORMACIONACADEMICA=?";
            cs = con.prepareCall(query);
            cs.setInt(1, idFormacion);
            rs = cs.executeQuery();

            if (rs.next()) {
                formacion = new Formacion();
                formacion.setIdFormacion(rs.getInt("idFORMACIONACADEMICA"));
                formacion.setId_cedula(rs.getInt("id_cedula"));
                formacion.setForm_nivelinstruccion(rs.getString("form_nivelinstruccion"));
                formacion.setForm_nrocersenecyt(rs.getString("form_nrocersenecyt"));
                formacion.setForm_institucioneducativa(rs.getString("form_institucioneducativa"));
                formacion.setForm_añosaprovados(rs.getString("form_añosaprovados"));
                formacion.setForm_areaconocimiento(rs.getString("form_areaconocimiento"));
                formacion.setForm_egresado_graduado(rs.getString("form_egresado_graduado"));
                formacion.setForm_titulobtenido(rs.getString("form_titulobtenido"));
                formacion.setForm_pais(rs.getString("form_pais"));
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener por ID: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return formacion;
    }

    public Boolean save(Formacion formacion) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "INSERT INTO formacionacademica (id_cedula, form_nivelinstruccion, form_nrocersenecyt, form_institucioneducativa, form_añosaprovados, form_areaconocimiento, form_egresado_graduado, form_titulobtenido, form_pais) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            cs = con.prepareCall(query);
            cs.setInt(1, formacion.getId_cedula());
            cs.setString(2, formacion.getForm_nivelinstruccion());
            cs.setString(3, formacion.getForm_nrocersenecyt());
            cs.setString(4, formacion.getForm_institucioneducativa());
            cs.setString(5, formacion.getForm_añosaprovados());
            cs.setString(6, formacion.getForm_areaconocimiento());
            cs.setString(7, formacion.getForm_egresado_graduado());
            cs.setString(8, formacion.getForm_titulobtenido());
            cs.setString(9, formacion.getForm_pais());

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean update(Formacion formacion) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "UPDATE formacionacademica SET id_cedula=?, form_nivelinstruccion=?, form_nrocersenecyt=?, form_institucioneducativa=?, form_añosaprovados=?, form_areaconocimiento=?, form_egresado_graduado=?, form_titulobtenido=?, form_pais=? WHERE idFORMACIONACADEMICA=?";
            cs = con.prepareCall(query);
            cs.setInt(1, formacion.getId_cedula());
            cs.setString(2, formacion.getForm_nivelinstruccion());
            cs.setString(3, formacion.getForm_nrocersenecyt());
            cs.setString(4, formacion.getForm_institucioneducativa());
            cs.setString(5, formacion.getForm_añosaprovados());
            cs.setString(6, formacion.getForm_areaconocimiento());
            cs.setString(7, formacion.getForm_egresado_graduado());
            cs.setString(8, formacion.getForm_titulobtenido());
            cs.setString(9, formacion.getForm_pais());
            cs.setInt(10, formacion.getIdFormacion());

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al actualizar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean deleteById(Integer idFormacion) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "DELETE FROM formacionacademica WHERE idFORMACIONACADEMICA=?";
            cs = con.prepareCall(query);
            cs.setInt(1, idFormacion);

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al eliminar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    private void cerrarRecursos() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (cs != null) {
                cs.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            System.out.println("Error al cerrar recursos: " + ex.getMessage());
        }
    }
}
