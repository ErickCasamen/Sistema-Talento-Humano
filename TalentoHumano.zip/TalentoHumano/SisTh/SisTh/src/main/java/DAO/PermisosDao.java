package DAO;

import BD.Conexion;
import MODELO.Permiso;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PermisosDao {

    // Estancias necesarias para la lógica
    Conexion cn = new Conexion();
    CallableStatement cs;
    Connection con;
    ResultSet rs;

    public List<Permiso> getAll() {
        ArrayList<Permiso> lista = new ArrayList<>();
        try {
            con = cn.getConexion();
            cs = con.prepareCall("call getAllPermiso()");
            rs = cs.executeQuery();
            while (rs.next()) {
                Permiso permiso = new Permiso();
                permiso.setIdPermiso(rs.getInt(1));
                permiso.setId_cedula(rs.getInt(2));
                permiso.setPer_fecha(rs.getString(3));
                permiso.setPer_provincia(rs.getString(4));
                permiso.setPer_regimen(rs.getString(5));
                permiso.setPer_Apellidos(rs.getString(6));
                permiso.setPer_Nombres(rs.getString(7));
                permiso.setPer_cedula(rs.getString(8));
                permiso.setPer_cordinacionzonal(rs.getString(9));
                permiso.setPer_direccionunidad(rs.getString(10));
                permiso.setPer_motivo(rs.getString(11));
                permiso.setPer_horas(rs.getString(12));
                permiso.setPer_dias(rs.getString(13));
                permiso.setPer_valordescontar(rs.getString(14));
                lista.add(permiso);
            }
        } catch (SQLException ex) {
            System.out.println("Error al listar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return lista;
    }

    public Permiso getById(Integer idPermiso) {
        Permiso permiso = null;
        try {
            con = cn.getConexion();
            String query = "SELECT * FROM permiso WHERE idPERMISOS=?";
            cs = con.prepareCall(query);
            cs.setInt(1, idPermiso);
            rs = cs.executeQuery();

            if (rs.next()) {
                permiso = new Permiso();
                permiso.setIdPermiso(rs.getInt("idPERMISOS"));
                permiso.setId_cedula(rs.getInt("id_cedula"));
                permiso.setPer_fecha(rs.getString("per_fecha"));
                permiso.setPer_provincia(rs.getString("per_provincia"));
                permiso.setPer_regimen(rs.getString("per_regimen"));
                permiso.setPer_Apellidos(rs.getString("per_Apellidos"));
                permiso.setPer_Nombres(rs.getString("per_Nombres"));
                permiso.setPer_cedula(rs.getString("per_cedula"));
                permiso.setPer_cordinacionzonal(rs.getString("per_cordinacionzonal"));
                permiso.setPer_direccionunidad(rs.getString("per_direccionunidad"));
                permiso.setPer_motivo(rs.getString("per_motivo"));
                permiso.setPer_horas(rs.getString("per_horas"));
                permiso.setPer_dias(rs.getString("per_dias"));
                permiso.setPer_valordescontar(rs.getString("per_valordescontar"));
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener por ID: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return permiso;
    }

    public Boolean save(Permiso permiso) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "INSERT INTO permiso (id_cedula, per_fecha, per_provincia, per_regimen, per_Apellidos, per_Nombres, per_cedula, per_cordinacionzonal, per_direccionunidad, per_motivo, per_horas, per_dias, per_valordescontar) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            cs = con.prepareCall(query);
            cs.setInt(1, permiso.getId_cedula());
            cs.setString(2, permiso.getPer_fecha());
            cs.setString(3, permiso.getPer_provincia());
            cs.setString(4, permiso.getPer_regimen());
            cs.setString(5, permiso.getPer_Apellidos());
            cs.setString(6, permiso.getPer_Nombres());
            cs.setString(7, permiso.getPer_cedula());
            cs.setString(8, permiso.getPer_cordinacionzonal());
            cs.setString(9, permiso.getPer_direccionunidad());
            cs.setString(10, permiso.getPer_motivo());
            cs.setString(11, permiso.getPer_horas());
            cs.setString(12, permiso.getPer_dias());
            cs.setString(13, permiso.getPer_valordescontar());

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean update(Permiso permiso) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "UPDATE permiso SET id_cedula=?, per_fecha=?, per_provincia=?, per_regimen=?, per_Apellidos=?, per_Nombres=?, per_cedula=?, per_cordinacionzonal=?, per_direccionunidad=?, per_motivo=?, per_horas=?, per_dias=?, per_valordescontar=? WHERE idPERMISOS=?";
            cs = con.prepareCall(query);
            cs.setInt(1, permiso.getId_cedula());
            cs.setString(2, permiso.getPer_fecha());
            cs.setString(3, permiso.getPer_provincia());
            cs.setString(4, permiso.getPer_regimen());
            cs.setString(5, permiso.getPer_Apellidos());
            cs.setString(6, permiso.getPer_Nombres());
            cs.setString(7, permiso.getPer_cedula());
            cs.setString(8, permiso.getPer_cordinacionzonal());
            cs.setString(9, permiso.getPer_direccionunidad());
            cs.setString(10, permiso.getPer_motivo());
            cs.setString(11, permiso.getPer_horas());
            cs.setString(12, permiso.getPer_dias());
            cs.setString(13, permiso.getPer_valordescontar());
            cs.setInt(14, permiso.getIdPermiso());

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al actualizar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean deleteById(Integer idPermiso) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "DELETE FROM permiso WHERE idPERMISOS=?";
            cs = con.prepareCall(query);
            cs.setInt(1, idPermiso);

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al eliminar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    private void cerrarRecursos() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (cs != null) {
                cs.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            System.out.println("Error al cerrar recursos: " + ex.getMessage());
        }
    }
}
