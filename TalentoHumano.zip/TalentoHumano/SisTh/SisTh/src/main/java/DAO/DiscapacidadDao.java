package DAO;

import BD.Conexion;
import MODELO.Discapacidad;
import interfaces.DiscapacidadCRUD;
import java.sql.*;
import java.util.*;

public class DiscapacidadDao implements DiscapacidadCRUD {
    //Estancias necesarias para la logica

    Discapacidad discapacidad = new Discapacidad();
    Conexion cn = new Conexion();
    CallableStatement cs;
    Connection con;
    ResultSet rs;

    @Override
    public List<Discapacidad> getAll() {
        ArrayList<Discapacidad> lista = new ArrayList<>();
        try {

            con = (Connection) cn.getConexion();
            cs = con.prepareCall("call getAllDiscapacidad()");
            rs = cs.executeQuery();
            while (rs.next()) {
                Discapacidad dis = new Discapacidad();
                dis.setIdDiscapacidad(rs.getInt(1));
                dis.setId_cedula(rs.getInt(2));
                dis.setDisc_situacion(rs.getString(3));
                dis.setDisc_tiporelacion(rs.getString(4));
                dis.setDisc_nroconadis(rs.getString(5));
                dis.setDisc_certificiado_enfermedad(rs.getString(6));
                dis.setDisc_tipodiscapacidad(rs.getString(7));
                dis.setDisc_porcentaje(rs.getString(8));
                dis.setDisc_tipoenfermedad(rs.getString(9));

                lista.add(dis);
            }
        } catch (SQLException ex) {
            System.out.println("Error al listar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return lista;
    }

    public Discapacidad getByIdCapacitacion(Integer idDiscapacidad) {
        Discapacidad cli = null;
        try {
            con = cn.getConexion();
            String query = "SELECT * FROM discapacidad WHERE idDISCAPACIDAD=?";
            cs = con.prepareCall(query);

            // Establecer el valor del parámetro en el PreparedStatement
            cs.setInt(1, idDiscapacidad);

            // Ejecutar la consulta
            rs = cs.executeQuery();

            // Verificar si se encontró el registro
            if (rs.next()) {
                cli = new Discapacidad();
                cli.setIdDiscapacidad(rs.getInt("idDISCAPACIDAD"));
                cli.setId_cedula(rs.getInt("DOCENTE_id_cedula"));
                cli.setDisc_situacion(rs.getString("disc_situacion"));
                cli.setDisc_tiporelacion(rs.getString("disc_tiporelacion"));
                cli.setDisc_nroconadis(rs.getString("disc_nroconadis"));
                cli.setDisc_certificiado_enfermedad(rs.getString("disc_certificado_enfermedad"));
                cli.setDisc_tipodiscapacidad(rs.getString("disc_tipodiscapacidad"));
                cli.setDisc_porcentaje(rs.getString("disc_porcentaje"));
                cli.setDisc_tipoenfermedad(rs.getString("disc_tipoenfermedad"));

            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener por ID: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return cli;
    }

    public Boolean save(Discapacidad discapacidad) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "INSERT INTO discapacidad ("
                    + "DOCENTE_id_cedula,"
                    + "disc_situacion,"
                    + "disc_tiporelacion, "
                    + "disc_nroconadis, "
                    + "disc_certificado_enfermedad, "
                    + "disc_tipodiscapacidad, "
                    + "disc_porcentaje, "
                    + "disc_tipoenfermedad, "
                    + ")"
                    + " VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            cs = con.prepareCall(query);

            // Establecer valores de parámetros en el PreparedStatement
            cs.setInt(1, discapacidad.getId_cedula());
            cs.setString(2, discapacidad.getDisc_situacion());
            cs.setString(3, discapacidad.getDisc_tiporelacion());
            cs.setString(4, discapacidad.getDisc_nroconadis());
            cs.setString(5, discapacidad.getDisc_certificiado_enfermedad());
            cs.setString(6, discapacidad.getDisc_tipodiscapacidad());
            cs.setString(7, discapacidad.getDisc_porcentaje());
            cs.setString(8, discapacidad.getDisc_tipoenfermedad());

            // Ejecutar la inserción
            int rowsAffected = cs.executeUpdate();

            // Verificar si la inserción fue exitosa
            success = (rowsAffected > 0);

        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean update(Discapacidad discapacidad) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "UPDATE discapacidad SET "
                    + "DOCENTE_id_cedula,"
                    + "disc_situacion,"
                    + "disc_tiporelacion, "
                    + "disc_nroconadis, "
                    + "disc_certificado_enfermedad, "
                    + "disc_tipodiscapacidad, "
                    + "disc_porcentaje, "
                    + "disc_tipoenfermedad, "
                    + "WHERE idDISCAPACIDAD=?";
            cs = con.prepareCall(query);

            // Establecer valores de parámetros en el PreparedStatement
            cs.setInt(1, discapacidad.getId_cedula());
            cs.setString(2, discapacidad.getDisc_situacion());
            cs.setString(3, discapacidad.getDisc_tiporelacion());
            cs.setString(4, discapacidad.getDisc_nroconadis());
            cs.setString(5, discapacidad.getDisc_certificiado_enfermedad());
            cs.setString(6, discapacidad.getDisc_tipodiscapacidad());
            cs.setString(7, discapacidad.getDisc_porcentaje());
            cs.setString(8, discapacidad.getDisc_tipoenfermedad());

            // Ejecutar la actualización
            int rowsAffected = cs.executeUpdate();

            // Verificar si la actualización fue exitosa
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al actualizar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean deleteById(Integer idDiscapacidad) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "DELETE FROM discapacidad WHERE idDISCAPACIDAD=?";
            cs = con.prepareCall(query);

            // Establecer el valor del parámetro en el PreparedStatement
            cs.setInt(1, idDiscapacidad);

            // Ejecutar la eliminación
            int rowsAffected = cs.executeUpdate();

            // Verificar si la eliminación fue exitosa
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al eliminar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    private void cerrarRecursos() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (cs != null) {
                cs.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            System.out.println("Error al cerrar recursos: " + ex.getMessage());
        }
    }

}
