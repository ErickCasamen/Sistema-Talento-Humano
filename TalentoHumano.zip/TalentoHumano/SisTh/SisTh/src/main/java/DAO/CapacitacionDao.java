package DAO;

import BD.Conexion;
import MODELO.capacitacion;
import interfaces.CapacitacionesCRUD;
import java.sql.*;
import java.util.*;

public class CapacitacionDao implements CapacitacionesCRUD {

    //Estancias necesarias para la logica
    capacitacion capacitacion = new capacitacion();
    Conexion cn = new Conexion();
    CallableStatement cs;
    Connection con;
    ResultSet rs;

    @Override
    public List<capacitacion> getAll() {
        ArrayList<capacitacion> lista = new ArrayList<>();
        try {

            con = (Connection) cn.getConexion();
            cs = con.prepareCall("call getAllCapacitaciones()");
            rs = cs.executeQuery();
            while (rs.next()) {
                capacitacion cap = new capacitacion();
                cap.setIdCapacitacion(rs.getInt(1));
                cap.setId_cedula(rs.getInt(2));
                cap.setCap_nombreevento(rs.getString(3));
                cap.setCap_tipo(rs.getString(4));
                cap.setCap_auspiciante(rs.getString(5));
                cap.setCap_horas(rs.getString(6));
                cap.setCap_tipocertificado(rs.getString(7));
                cap.setCap_institucion(rs.getString(8));
                cap.setCap_fechainicio(rs.getString(9));
                cap.setCap_fechafinal(rs.getString(10));
                lista.add(cap);
            }
        } catch (SQLException ex) {
            System.out.println("Error al listar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return lista;
    }

    @Override
    public capacitacion getByIdCapacitacion(Integer idCapacitacion) {
        capacitacion cli = null;
        try {
            con = cn.getConexion();
            String query = "SELECT * FROM capacitaciones WHERE idCAPACITACIONES=?";
            cs = con.prepareCall(query);

            // Establecer el valor del parámetro en el PreparedStatement
            cs.setInt(1, idCapacitacion);

            // Ejecutar la consulta
            rs = cs.executeQuery();

            // Verificar si se encontró el registro
            if (rs.next()) {
                cli = new capacitacion();
                cli.setIdCapacitacion(rs.getInt("idCAPACITACIONES"));
                cli.setId_cedula(rs.getInt("DOCENTE_id_cedula"));
                cli.setCap_nombreevento(rs.getString("cap_nombrevento"));
                cli.setCap_tipo(rs.getString("cap_tipo"));
                cli.setCap_auspiciante(rs.getString("cap_auspiciante"));
                cli.setCap_horas(rs.getString("cap_horas"));
                cli.setCap_tipocertificado(rs.getString("cap_tipocertificado"));
                cli.setCap_institucion(rs.getString("cap_institucion"));
                cli.setCap_fechainicio(rs.getString("cap_fechainicio"));
                cli.setCap_fechafinal(rs.getString("cap_fechafinal"));
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener por ID: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return cli;
    }

    @Override
    public Boolean save(capacitacion capacitacion) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "INSERT INTO capacitaciones ("
                    + "DOCENTE_id_cedula,"
                    + "cap_nombrevento,"
                    + "cap_tipo, "
                    + "cap_auspiciante, "
                    + "cap_horas, "
                    + "cap_tipocertificado, "
                    + "cap_institucion, "
                    + "cap_fechainicio, "
                    + "cap_fechafinal"
                    + ")"
                    + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            cs = con.prepareCall(query);

            // Establecer valores de parámetros en el PreparedStatement
            cs.setInt(1, capacitacion.getId_cedula());
            cs.setString(2, capacitacion.getCap_nombreevento());
            cs.setString(3, capacitacion.getCap_tipo());
            cs.setString(4, capacitacion.getCap_auspiciante());
            cs.setString(5, capacitacion.getCap_horas());
            cs.setString(6, capacitacion.getCap_tipocertificado());
            cs.setString(7, capacitacion.getCap_institucion());
            cs.setString(8, capacitacion.getCap_fechainicio());
            cs.setString(9, capacitacion.getCap_fechafinal());

            // Ejecutar la inserción
            int rowsAffected = cs.executeUpdate();

            // Verificar si la inserción fue exitosa
            success = (rowsAffected > 0);

        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    @Override
    public Boolean update(capacitacion capacitacion) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "UPDATE capacitaciones SET "
                    + "DOCENTE_id_cedula=?, "
                    + "cap_nombrevento=?, "
                    + "cap_tipo=?, "
                    + "cap_auspiciante=?, "
                    + "cap_horas=?, "
                    + "cap_tipocertificado=?, "
                    + "cap_institucion=?, "
                    + "cap_fechainicio=?, "
                    + "cap_fechafinal=? "
                    + "WHERE idCAPACITACIONES=?";
            cs = con.prepareCall(query);

            // Establecer valores de parámetros en el PreparedStatement
            cs.setInt(1, capacitacion.getId_cedula());
            cs.setString(2, capacitacion.getCap_nombreevento());
            cs.setString(3, capacitacion.getCap_tipo());
            cs.setString(4, capacitacion.getCap_auspiciante());
            cs.setString(5, capacitacion.getCap_horas());
            cs.setString(6, capacitacion.getCap_tipocertificado());
            cs.setString(7, capacitacion.getCap_institucion());
            cs.setString(8, capacitacion.getCap_fechainicio());
            cs.setString(9, capacitacion.getCap_fechafinal());
            cs.setInt(10, capacitacion.getIdCapacitacion());

            // Ejecutar la actualización
            int rowsAffected = cs.executeUpdate();

            // Verificar si la actualización fue exitosa
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al actualizar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    @Override
    public Boolean deleteById(Integer idCapacitacion) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "DELETE FROM capacitaciones WHERE idCAPACITACIONES=?";
            cs = con.prepareCall(query);

            // Establecer el valor del parámetro en el PreparedStatement
            cs.setInt(1, idCapacitacion);

            // Ejecutar la eliminación
            int rowsAffected = cs.executeUpdate();

            // Verificar si la eliminación fue exitosa
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al eliminar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    private void cerrarRecursos() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (cs != null) {
                cs.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            System.out.println("Error al cerrar recursos: " + ex.getMessage());
        }
    }

}
