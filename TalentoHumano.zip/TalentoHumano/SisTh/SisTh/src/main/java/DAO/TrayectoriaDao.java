package DAO;

import BD.Conexion;
import MODELO.Trayectoria;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TrayectoriaDao {

    // Estancias necesarias para la lógica
    Conexion cn = new Conexion();
    CallableStatement cs;
    Connection con;
    ResultSet rs;

    
    public List<Trayectoria> getAll() {
        ArrayList<Trayectoria> lista = new ArrayList<>();
        try {
            con = cn.getConexion();
            cs = con.prepareCall("call getAllTrayectoria()");
            rs = cs.executeQuery();
            while (rs.next()) {
                Trayectoria trayectoria = new Trayectoria();
                trayectoria.setIdTrayectoria(rs.getInt(1));
                trayectoria.setId_cedula(rs.getInt(2));
                trayectoria.setTray_institucion(rs.getString(3));
                trayectoria.setTray_organizacionnombre(rs.getString(4));
                trayectoria.setTray_unidadadministrativa(rs.getString(5));
                trayectoria.setTray_denominacionpuesto(rs.getString(6));
                trayectoria.setTray_fechaingreso(rs.getString(7));
                trayectoria.setTray_fechasalida(rs.getString(8));
                trayectoria.setTray_tipoingreso(rs.getString(9));
                trayectoria.setTray_motivosalida(rs.getString(10));
                lista.add(trayectoria);
            }
        } catch (SQLException ex) {
            System.out.println("Error al listar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return lista;
    }

    public Trayectoria getById(Integer idTrayectoria) {
        Trayectoria trayectoria = null;
        try {
            con = cn.getConexion();
            String query = "SELECT * FROM trayectorialaboral WHERE idTRAYECTORIALABORAL=?";
            cs = con.prepareCall(query);
            cs.setInt(1, idTrayectoria);
            rs = cs.executeQuery();

            if (rs.next()) {
                trayectoria = new Trayectoria();
                trayectoria.setIdTrayectoria(rs.getInt("idTRAYECTORIALABORAL"));
                trayectoria.setId_cedula(rs.getInt("id_cedula"));
                trayectoria.setTray_institucion(rs.getString("tray_institucion"));
                trayectoria.setTray_organizacionnombre(rs.getString("tray_organizacionnombre"));
                trayectoria.setTray_unidadadministrativa(rs.getString("tray_unidadadministrativa"));
                trayectoria.setTray_denominacionpuesto(rs.getString("tray_denominacionpuesto"));
                trayectoria.setTray_fechaingreso(rs.getString("tray_fechaingreso"));
                trayectoria.setTray_fechasalida(rs.getString("tray_fechasalida"));
                trayectoria.setTray_tipoingreso(rs.getString("tray_tipoingreso"));
                trayectoria.setTray_motivosalida(rs.getString("tray_motivosalida"));
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener por ID: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return trayectoria;
    }

    public Boolean save(Trayectoria trayectoria) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "INSERT INTO trayectorialaboral (id_cedula, tray_institucion, tray_organizacionnombre, tray_unidadadministrativa, tray_denominacionpuesto, tray_fechaingreso, tray_fechasalida, tray_tipoingreso, tray_motivosalida) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            cs = con.prepareCall(query);
            cs.setInt(1, trayectoria.getId_cedula());
            cs.setString(2, trayectoria.getTray_institucion());
            cs.setString(3, trayectoria.getTray_organizacionnombre());
            cs.setString(4, trayectoria.getTray_unidadadministrativa());
            cs.setString(5, trayectoria.getTray_denominacionpuesto());
            cs.setString(6, trayectoria.getTray_fechaingreso());
            cs.setString(7, trayectoria.getTray_fechasalida());
            cs.setString(8, trayectoria.getTray_tipoingreso());
            cs.setString(9, trayectoria.getTray_motivosalida());

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean update(Trayectoria trayectoria) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "UPDATE trayectorialaboral SET id_cedula=?, tray_institucion=?, tray_organizacionnombre=?, tray_unidadadministrativa=?, tray_denominacionpuesto=?, tray_fechaingreso=?, tray_fechasalida=?, tray_tipoingreso=?, tray_motivosalida=? WHERE idTRAYECTORIALABORAL=?";
            cs = con.prepareCall(query);
            cs.setInt(1, trayectoria.getId_cedula());
            cs.setString(2, trayectoria.getTray_institucion());
            cs.setString(3, trayectoria.getTray_organizacionnombre());
            cs.setString(4, trayectoria.getTray_unidadadministrativa());
            cs.setString(5, trayectoria.getTray_denominacionpuesto());
            cs.setString(6, trayectoria.getTray_fechaingreso());
            cs.setString(7, trayectoria.getTray_fechasalida());
            cs.setString(8, trayectoria.getTray_tipoingreso());
            cs.setString(9, trayectoria.getTray_motivosalida());
            cs.setInt(10, trayectoria.getIdTrayectoria());

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al actualizar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean deleteById(Integer idTrayectoria) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "DELETE FROM trayectorialaboral WHERE idTRAYECTORIALABORAL=?";
            cs = con.prepareCall(query);
            cs.setInt(1, idTrayectoria);

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al eliminar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    private void cerrarRecursos() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (cs != null) {
                cs.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            System.out.println("Error al cerrar recursos: " + ex.getMessage());
        }
    }
}
