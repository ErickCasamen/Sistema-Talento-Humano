package DAO;

import BD.Conexion;
import MODELO.Informacion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InformacionDao {

    // Estancias necesarias para la lógica
    Conexion cn = new Conexion();
    CallableStatement cs;
    Connection con;
    ResultSet rs;

    
    public List<Informacion> getAll() {
        ArrayList<Informacion> lista = new ArrayList<>();
        try {
            con = cn.getConexion();
            cs = con.prepareCall("call getAllInformacion()");
            rs = cs.executeQuery();
            while (rs.next()) {
                Informacion informacion = new Informacion();
                informacion.setIdInformacion(rs.getInt(1));
                informacion.setId_cedula(rs.getInt(2));
                informacion.setInf_insfinanciera(rs.getString(3));
                informacion.setInf_tipocuenta(rs.getString(4));
                informacion.setInf_nrocuenta(rs.getString(5));
                lista.add(informacion);
            }
        } catch (SQLException ex) {
            System.out.println("Error al listar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return lista;
    }

    public Informacion getById(Integer idInformacion) {
        Informacion informacion = null;
        try {
            con = cn.getConexion();
            String query = "SELECT * FROM informacionbancaria WHERE idINFORMACIONBANCARIA=?";
            cs = con.prepareCall(query);
            cs.setInt(1, idInformacion);
            rs = cs.executeQuery();

            if (rs.next()) {
                informacion = new Informacion();
                informacion.setIdInformacion(rs.getInt("idINFORMACIONBANCARIA"));
                informacion.setId_cedula(rs.getInt("id_cedula"));
                informacion.setInf_insfinanciera(rs.getString("inf_insfinanciera"));
                informacion.setInf_tipocuenta(rs.getString("inf_tipocuenta"));
                informacion.setInf_nrocuenta(rs.getString("inf_nrocuenta"));
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener por ID: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return informacion;
    }

    public Boolean save(Informacion informacion) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "INSERT INTO informacionbancaria (id_cedula, inf_insfinanciera, inf_tipocuenta, inf_nrocuenta) VALUES (?, ?, ?, ?)";
            cs = con.prepareCall(query);
            cs.setInt(1, informacion.getId_cedula());
            cs.setString(2, informacion.getInf_insfinanciera());
            cs.setString(3, informacion.getInf_tipocuenta());
            cs.setString(4, informacion.getInf_nrocuenta());

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean update(Informacion informacion) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "UPDATE informacionbancaria SET id_cedula=?, inf_insfinanciera=?, inf_tipocuenta=?, inf_nrocuenta=? WHERE idINFORMACIONBANCARIA=?";
            cs = con.prepareCall(query);
            cs.setInt(1, informacion.getId_cedula());
            cs.setString(2, informacion.getInf_insfinanciera());
            cs.setString(3, informacion.getInf_tipocuenta());
            cs.setString(4, informacion.getInf_nrocuenta());
            cs.setInt(5, informacion.getIdInformacion());

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al actualizar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean deleteById(Integer idInformacion) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "DELETE FROM informacionbancaria WHERE idINFORMACIONBANCARIA=?";
            cs = con.prepareCall(query);
            cs.setInt(1, idInformacion);

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al eliminar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    private void cerrarRecursos() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (cs != null) {
                cs.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            System.out.println("Error al cerrar recursos: " + ex.getMessage());
        }
    }
}
