package DAO;

import BD.Conexion;
import MODELO.Senecyt;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SenecytDao {

    // Estancias necesarias para la lógica
    Conexion cn = new Conexion();
    CallableStatement cs;
    Connection con;
    ResultSet rs;

   
    public List<Senecyt> getAll() {
        ArrayList<Senecyt> lista = new ArrayList<>();
        try {
            con = cn.getConexion();
            cs = con.prepareCall("call getAllSenecyt()");
            rs = cs.executeQuery();
            while (rs.next()) {
                Senecyt senecyt = new Senecyt();
                senecyt.setIdSenecyt(rs.getInt(1));
                senecyt.setId_cedula(rs.getInt(2));
                senecyt.setSis_fechaingreso(rs.getString(3));
                senecyt.setSis_fechasalida(rs.getString(4));
                senecyt.setSis_unidad(rs.getString(5));
                senecyt.setSis_modalidad(rs.getString(6));
                senecyt.setSis_grupocupacional(rs.getString(7));
                senecyt.setSis_puesto(rs.getString(8));
                lista.add(senecyt);
            }
        } catch (SQLException ex) {
            System.out.println("Error al listar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return lista;
    }

    public Senecyt getById(Integer idSenecyt) {
        Senecyt senecyt = null;
        try {
            con = cn.getConexion();
            String query = "SELECT * FROM senecyt WHERE idSENECYT=?";
            cs = con.prepareCall(query);
            cs.setInt(1, idSenecyt);
            rs = cs.executeQuery();

            if (rs.next()) {
                senecyt = new Senecyt();
                senecyt.setIdSenecyt(rs.getInt("idSENECYT"));
                senecyt.setId_cedula(rs.getInt("id_cedula"));
                senecyt.setSis_fechaingreso(rs.getString("sis_fechaingreso"));
                senecyt.setSis_fechasalida(rs.getString("sis_fechasalida"));
                senecyt.setSis_unidad(rs.getString("sis_unidad"));
                senecyt.setSis_modalidad(rs.getString("sis_modalidad"));
                senecyt.setSis_grupocupacional(rs.getString("sis_grupocupacional"));
                senecyt.setSis_puesto(rs.getString("sis_puesto"));
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener por ID: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return senecyt;
    }

    public Boolean save(Senecyt senecyt) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "INSERT INTO senecyt (id_cedula, sis_fechaingreso, sis_fechasalida, sis_unidad, sis_modalidad, sis_grupocupacional, sis_puesto) VALUES (?, ?, ?, ?, ?, ?, ?)";
            cs = con.prepareCall(query);
            cs.setInt(1, senecyt.getId_cedula());
            cs.setString(2, senecyt.getSis_fechaingreso());
            cs.setString(3, senecyt.getSis_fechasalida());
            cs.setString(4, senecyt.getSis_unidad());
            cs.setString(5, senecyt.getSis_modalidad());
            cs.setString(6, senecyt.getSis_grupocupacional());
            cs.setString(7, senecyt.getSis_puesto());

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean update(Senecyt senecyt) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "UPDATE senecyt SET id_cedula=?, sis_fechaingreso=?, sis_fechasalida=?, sis_unidad=?, sis_modalidad=?, sis_grupocupacional=?, sis_puesto=? WHERE idSENECYT=?";
            cs = con.prepareCall(query);
            cs.setInt(1, senecyt.getId_cedula());
            cs.setString(2, senecyt.getSis_fechaingreso());
            cs.setString(3, senecyt.getSis_fechasalida());
            cs.setString(4, senecyt.getSis_unidad());
            cs.setString(5, senecyt.getSis_modalidad());
            cs.setString(6, senecyt.getSis_grupocupacional());
            cs.setString(7, senecyt.getSis_puesto());
            cs.setInt(8, senecyt.getIdSenecyt());

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al actualizar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean deleteById(Integer idSenecyt) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "DELETE FROM senecyt WHERE idSENECYT=?";
            cs = con.prepareCall(query);
            cs.setInt(1, idSenecyt);

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al eliminar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    private void cerrarRecursos() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (cs != null) {
                cs.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            System.out.println("Error al cerrar recursos: " + ex.getMessage());
        }
    }
}
