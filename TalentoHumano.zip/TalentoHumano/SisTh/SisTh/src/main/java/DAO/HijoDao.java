package DAO;

import BD.Conexion;
import MODELO.Hijo;
import interfaces.HijoCrud;
import java.sql.*;
import java.util.*;

public class HijoDao implements HijoCrud {

    //Estancias necesarias para la logica
    Hijo hijo = new Hijo();
    Conexion cn = new Conexion();
    CallableStatement cs;
    Connection con;
    ResultSet rs;

    @Override
    public List<Hijo> getAll() {
        ArrayList<Hijo> lista = new ArrayList<>();
        try {

            con = (Connection) cn.getConexion();
            cs = con.prepareCall("call getAllHijos()");
            rs = cs.executeQuery();
            while (rs.next()) {
                Hijo hi = new Hijo();
                hi.setIdHIJOS(rs.getInt(1));
                hi.setId_cedula(rs.getInt(2));
                hi.setHi_cedula(rs.getString(3));
                hi.setHi_nombres(rs.getString(4));
                hi.setHi_apellidos(rs.getString(5));
                hi.setHi_nivelinstitucional(rs.getString(6));
                lista.add(hi);
            }
        } catch (SQLException ex) {
            System.out.println("Error al listar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return lista;
    }

    @Override
    public Hijo getById(Integer idHijo) {
        Hijo hijo = null;
        try {
            con = (Connection) cn.getConexion();
            String sql = "SELECT * FROM Hijo WHERE idHIJOS = ?";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, idHijo);
                rs = ps.executeQuery();
                if (rs.next()) {
                    hijo = new Hijo();
                    hijo.setIdHIJOS(rs.getInt(1));
                    hijo.setId_cedula(rs.getInt(2));
                    hijo.setHi_nombres(rs.getString(3));
                    hijo.setHi_apellidos(rs.getString(4));
                    hijo.setHi_nivelinstitucional(rs.getString(5));
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener el hijo por ID: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return hijo;
    }

    @Override
    public Boolean deleteById(Integer idHijo) {
        Boolean success = false;
        try {
            con = (Connection) cn.getConexion();
            String sql = "DELETE FROM Hijo WHERE idHIJOS = ?";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, idHijo);
                success = ps.executeUpdate() > 0;
            }
        } catch (SQLException ex) {
            System.out.println("Error al eliminar el hijo: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    @Override
    public Boolean save(Hijo hijo) {
        Boolean success = false;
        try {
            con = (Connection) cn.getConexion();
            String sql = "INSERT INTO Hijo "
                    + "DOCENTE_id_cedula,"
                    + "(id_cedula, "
                    + "hi_nombres, "
                    + "hi_apellidos, "
                    + "hi_nivelinstitucional) "
                    + "VALUES (?, ?, ?, ?)";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, hijo.getId_cedula());
                ps.setString(2, hijo.getHi_nombres());
                ps.setString(3, hijo.getHi_apellidos());
                ps.setString(4, hijo.getHi_nivelinstitucional());
                success = ps.executeUpdate() > 0;
            }
        } catch (SQLException ex) {
            System.out.println("Error al guardar el hijo: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    @Override
    public Boolean update(Hijo hijo) {
        Boolean success = false;
        try {
            con = (Connection) cn.getConexion();
            String sql = "UPDATE Hijo SET "
                    + "DOCENTE_id_cedula=?, "
                    + "id_cedula = ?, "
                    + "hi_nombres = ?, "
                    + "hi_apellidos = ?, "
                    + "hi_nivelinstitucional = ? "
                    + "WHERE idHIJOS = ?";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, hijo.getId_cedula());
                ps.setString(2, hijo.getHi_nombres());
                ps.setString(3, hijo.getHi_apellidos());
                ps.setString(4, hijo.getHi_nivelinstitucional());
                ps.setInt(5, hijo.getIdHIJOS());
                success = ps.executeUpdate() > 0;
            }
        } catch (SQLException ex) {
            System.out.println("Error al actualizar el hijo: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    private void cerrarRecursos() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (cs != null) {
                cs.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            System.out.println("Error al cerrar recursos: " + ex.getMessage());
        }
    }

}
