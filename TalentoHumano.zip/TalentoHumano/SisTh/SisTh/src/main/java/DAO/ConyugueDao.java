package DAO;

import BD.Conexion;
import MODELO.Conyugues;
import MODELO.capacitacion;
import interfaces.ConyugueCRUD;
import java.sql.*;
import java.util.*;

public class ConyugueDao implements ConyugueCRUD {

    //Estancias necesarias para la logica
    capacitacion capacitacion = new capacitacion();
    Conexion cn = new Conexion();
    CallableStatement cs;
    Connection con;
    ResultSet rs;

    @Override
    public List<Conyugues> getAll() {
        ArrayList<Conyugues> lista = new ArrayList<>();
        try {

            con = (Connection) cn.getConexion();
            cs = con.prepareCall("call getAllConyugue()");
            rs = cs.executeQuery();
            while (rs.next()) {
                Conyugues coy = new Conyugues();
                coy.setIdConyugue(rs.getInt(1));
                coy.setId_cedula(rs.getInt(2));
                coy.setCony_tiporelacion(rs.getString(3));
                coy.setCony_cedula(rs.getString(4));
                coy.setCony_apellidos(rs.getString(5));
                coy.setCony_nombres(rs.getString(6));
                lista.add(coy);
            }
        } catch (SQLException ex) {
            System.out.println("Error al listar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return lista;
    }

    public Conyugues getById(Integer idConyugue) {
        Conyugues cli = null;
        try {
            con = cn.getConexion();
            String query = "SELECT * FROM conyugue WHERE idCONYUGE=?";
            cs = con.prepareCall(query);

            // Establecer el valor del parámetro en el PreparedStatement
            cs.setInt(1, idConyugue);

            // Ejecutar la consulta
            rs = cs.executeQuery();

            // Verificar si se encontró el registro
            if (rs.next()) {
                cli = new Conyugues();
                cli.setIdConyugue(rs.getInt("idCONYUGE"));
                cli.setId_cedula(rs.getInt("DOCENTE_id_cedula"));
                cli.setCony_tiporelacion(rs.getString("cony_tiporelacion"));
                cli.setCony_cedula(rs.getString("cony_cedula"));
                cli.setCony_apellidos(rs.getString("cony_apellidos"));
                cli.setCony_nombres(rs.getString("cony_nombres"));
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener por ID: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return cli;
    }

    public Boolean save(Conyugues conyugue) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "INSERT INTO conyugue ("
                    + "DOCENTE_id_cedula,"
                    + "cony_tiporelacion,"
                    + "cony_cedula, "
                    + "cony_apellidos, "
                    + "cony_nombres "
                    + ")"
                    + " VALUES (?, ?, ?, ?, ?)";
            cs = con.prepareCall(query);

            // Establecer valores de parámetros en el PreparedStatement
            cs.setInt(1, conyugue.getId_cedula());
            cs.setString(2, conyugue.getCony_tiporelacion());
            cs.setString(3, conyugue.getCony_cedula());
            cs.setString(4, conyugue.getCony_apellidos());
            cs.setString(5, conyugue.getCony_nombres());

            // Ejecutar la inserción
            int rowsAffected = cs.executeUpdate();

            // Verificar si la inserción fue exitosa
            success = (rowsAffected > 0);

        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean update(Conyugues conyugue) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "UPDATE conyugue SET "
                    + "cony_tiporelacion=?, "
                    + "cony_cedula=?, "
                    + "cony_apellidos=?, "
                    + "cony_nombres=? "
                    + "WHERE idCONYUGE=?";

            cs = con.prepareCall(query);

            // Establecer valores de parámetros en el PreparedStatement
            cs.setString(1, conyugue.getCony_tiporelacion());
            cs.setString(2, conyugue.getCony_cedula());
            cs.setString(3, conyugue.getCony_apellidos());
            cs.setString(4, conyugue.getCony_nombres());
            cs.setInt(5, conyugue.getIdConyugue());

            // Ejecutar la actualización
            int rowsAffected = cs.executeUpdate();

            // Verificar si la actualización fue exitosa
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al actualizar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean deleteById(Integer idConyugue) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "DELETE FROM conyugue WHERE idCONYUGE=?";
            cs = con.prepareCall(query);

            // Establecer el valor del parámetro en el PreparedStatement
            cs.setInt(1, idConyugue);

            // Ejecutar la eliminación
            int rowsAffected = cs.executeUpdate();

            // Verificar si la eliminación fue exitosa
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al eliminar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    private void cerrarRecursos() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (cs != null) {
                cs.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            System.out.println("Error al cerrar recursos: " + ex.getMessage());
        }
    }

}
