package DAO;

import BD.Conexion;
import MODELO.Evaluacion;
import interfaces.EvaluacionCrud;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EvaluacionDao implements EvaluacionCrud {

    // Estancias necesarias para la lógica
    Conexion cn = new Conexion();
    CallableStatement cs;
    Connection con;
    ResultSet rs;

    @Override
    public List<Evaluacion> getAll() {
        ArrayList<Evaluacion> lista = new ArrayList<>();
        try {
            con = cn.getConexion();
            cs = con.prepareCall("call getAllEvaluacion()");
            rs = cs.executeQuery();
            while (rs.next()) {
                Evaluacion eval = new Evaluacion();
                eval.setIdEvaluacion(rs.getInt(1));
                eval.setId_cedula(rs.getInt(2));
                eval.setEva_periodoinicio(rs.getString(3));
                eval.setEva_periodohasta(rs.getString(4));
                eval.setEva_nombre(rs.getString(5));
                eval.setEva_puntaje(rs.getString(6));
                eval.setEva_calificacion(rs.getString(7));
                eval.setEva_observacion(rs.getString(8));
                lista.add(eval);
            }
        } catch (SQLException ex) {
            System.out.println("Error al listar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return lista;
    }

    @Override
    public Evaluacion getById(Integer idEvaluacion) {
        Evaluacion eval = null;
        try {
            con = cn.getConexion();
            String query = "SELECT * FROM evaluacion WHERE idEVALUACION=?";
            cs = con.prepareCall(query);
            cs.setInt(1, idEvaluacion);
            rs = cs.executeQuery();

            if (rs.next()) {
                eval = new Evaluacion();
                eval.setIdEvaluacion(rs.getInt("idEVALUACION"));
                eval.setId_cedula(rs.getInt("id_cedula"));
                eval.setEva_periodoinicio(rs.getString("eva_periodoinicio"));
                eval.setEva_periodohasta(rs.getString("eva_periodohasta"));
                eval.setEva_nombre(rs.getString("eva_nombre"));
                eval.setEva_puntaje(rs.getString("eva_puntaje"));
                eval.setEva_calificacion(rs.getString("eva_calificacion"));
                eval.setEva_observacion(rs.getString("eva_observacion"));
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener por ID: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return eval;
    }

    public Boolean save(Evaluacion evaluacion) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "INSERT INTO evaluacion (id_cedula, eva_periodoinicio, eva_periodohasta, eva_nombre, eva_puntaje, eva_calificacion, eva_observacion) VALUES (?, ?, ?, ?, ?, ?, ?)";
            cs = con.prepareCall(query);
            cs.setInt(1, evaluacion.getId_cedula());
            cs.setString(2, evaluacion.getEva_periodoinicio());
            cs.setString(3, evaluacion.getEva_periodohasta());
            cs.setString(4, evaluacion.getEva_nombre());
            cs.setString(5, evaluacion.getEva_puntaje());
            cs.setString(6, evaluacion.getEva_calificacion());
            cs.setString(7, evaluacion.getEva_observacion());

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean update(Evaluacion evaluacion) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "UPDATE evaluacion SET id_cedula=?, eva_periodoinicio=?, eva_periodohasta=?, eva_nombre=?, eva_puntaje=?, eva_calificacion=?, eva_observacion=? WHERE idEVALUACION=?";
            cs = con.prepareCall(query);
            cs.setInt(1, evaluacion.getId_cedula());
            cs.setString(2, evaluacion.getEva_periodoinicio());
            cs.setString(3, evaluacion.getEva_periodohasta());
            cs.setString(4, evaluacion.getEva_nombre());
            cs.setString(5, evaluacion.getEva_puntaje());
            cs.setString(6, evaluacion.getEva_calificacion());
            cs.setString(7, evaluacion.getEva_observacion());
            cs.setInt(8, evaluacion.getIdEvaluacion());

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al actualizar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean deleteById(Integer idEvaluacion) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "DELETE FROM evaluacion WHERE idEVALUACION=?";
            cs = con.prepareCall(query);
            cs.setInt(1, idEvaluacion);

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al eliminar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    private void cerrarRecursos() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (cs != null) {
                cs.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            System.out.println("Error al cerrar recursos: " + ex.getMessage());
        }
    }
}
