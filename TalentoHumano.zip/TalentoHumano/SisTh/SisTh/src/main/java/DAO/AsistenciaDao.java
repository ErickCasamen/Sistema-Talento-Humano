package DAO;

import BD.Conexion;
import MODELO.Asistencia;
import interfaces.AsistenciaCRUD;
import java.sql.*;
import java.util.*;

public class  AsistenciaDao implements AsistenciaCRUD {

    //Estancias necesarias para la logica
    Asistencia asistencia = new Asistencia();
    Conexion cn = new Conexion();
    CallableStatement cs;
    Connection con;
    ResultSet rs;

    @Override
    public List<Asistencia> getAll() {
        ArrayList<Asistencia> lista = new ArrayList<>();
        try {

            con = (Connection) cn.getConexion();
            cs = con.prepareCall("call getAllAsistencia()");
            rs = cs.executeQuery();
            while (rs.next()) {
                Asistencia asi = new Asistencia();
                asi.setIdAsistencia(rs.getInt(1));
                asi.setId_cedula(rs.getInt(2));
                asi.setAsis_nombredocente(rs.getString(3));
                asi.setAsis_cargo(rs.getString(4));
                asi.setAsis_fecha(rs.getString(5));
                asi.setAsis_horaentrada(rs.getString(6));
                asi.setAsis_horasalida(rs.getString(7));
                asi.setAsis_observacion(rs.getString(8));

                lista.add(asi);
            }
        } catch (SQLException ex) {
            System.out.println("Error al listar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return lista;
    }

    public Asistencia getByIdCapacitacion(Integer idAsistencia) {
        Asistencia cli = null;
        try {
            con = cn.getConexion();
            String query = "SELECT * FROM asistencia WHERE idASISTENCIA=?";
            cs = con.prepareCall(query);

            // Establecer el valor del parámetro en el PreparedStatement
            cs.setInt(1, idAsistencia);

            // Ejecutar la consulta
            rs = cs.executeQuery();

            // Verificar si se encontró el registro
            if (rs.next()) {
                cli = new Asistencia();
                cli.setIdAsistencia(rs.getInt("idASISTENCIA"));
                cli.setId_cedula(rs.getInt("DOCENTE_id_cedula"));
                cli.setAsis_nombredocente(rs.getString("cap_nombrevento"));
                cli.setAsis_cargo(rs.getString("cap_tipo"));
                cli.setAsis_fecha(rs.getString("cap_auspiciante"));
                cli.setAsis_horaentrada(rs.getString("cap_horas"));
                cli.setAsis_horasalida(rs.getString("cap_tipocertificado"));
                cli.setAsis_observacion(rs.getString("cap_institucion"));

            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener por ID: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return cli;
    }

    @Override
    public Boolean save(Asistencia asistencia) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "INSERT INTO asistencia ("
                    + "DOCENTE_id_cedula,"
                    + "asis_nombredocente,"
                    + "asis_cargo,"
                    + "asis_fecha, "
                    + "asis_horaentrada, "
                    + "asis_horasalida, "
                    + "asis_observacion, "
                    + ")"
                    + " VALUES (?, ?, ?, ?, ?, ?, ?)";
            cs = con.prepareCall(query);

            // Establecer valores de parámetros en el PreparedStatement
            cs.setInt(1, asistencia.getId_cedula());
            cs.setString(2, asistencia.getAsis_nombredocente());
            cs.setString(3, asistencia.getAsis_cargo());
            cs.setString(4, asistencia.getAsis_fecha());
            cs.setString(5, asistencia.getAsis_horaentrada());
            cs.setString(6, asistencia.getAsis_horasalida());
            cs.setString(7, asistencia.getAsis_observacion());

            // Ejecutar la inserción
            int rowsAffected = cs.executeUpdate();

            // Verificar si la inserción fue exitosa
            success = (rowsAffected > 0);

        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    @Override
    public Boolean update(Asistencia asistencia) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "UPDATE asistencia SET "
                    + "DOCENTE_id_cedula,"
                    + "asis_nombredocente,"
                    + "asis_cargo,"
                    + "asis_fecha, "
                    + "asis_horaentrada, "
                    + "asis_horasalida, "
                    + "asis_observacion, "
                    + "WHERE idASISTENCIA=?";
            cs = con.prepareCall(query);

            // Establecer valores de parámetros en el PreparedStatement
            cs.setInt(1, asistencia.getId_cedula());
            cs.setString(2, asistencia.getAsis_nombredocente());
            cs.setString(3, asistencia.getAsis_cargo());
            cs.setString(4, asistencia.getAsis_fecha());
            cs.setString(5, asistencia.getAsis_horaentrada());
            cs.setString(6, asistencia.getAsis_horasalida());
            cs.setString(7, asistencia.getAsis_observacion());

            // Ejecutar la actualización
            int rowsAffected = cs.executeUpdate();

            // Verificar si la actualización fue exitosa
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al actualizar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    @Override
    public Boolean deleteById(Integer idAsistencia) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "DELETE FROM asistencia WHERE idASISTENCIA=?";
            cs = con.prepareCall(query);

            // Establecer el valor del parámetro en el PreparedStatement
            cs.setInt(1, idAsistencia);

            // Ejecutar la eliminación
            int rowsAffected = cs.executeUpdate();

            // Verificar si la eliminación fue exitosa
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al eliminar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    private void cerrarRecursos() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (cs != null) {
                cs.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            System.out.println("Error al cerrar recursos: " + ex.getMessage());
        }
    }

    @Override
    public Asistencia getById(Integer idHijo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
