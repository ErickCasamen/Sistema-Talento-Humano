package DAO;

import BD.Conexion;
import MODELO.Inclusion;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InclusionDao {

    // Estancias necesarias para la lógica
    Conexion cn = new Conexion();
    CallableStatement cs;
    Connection con;
    ResultSet rs;

    public List<Inclusion> getAll() {
        ArrayList<Inclusion> lista = new ArrayList<>();
        try {
            con = cn.getConexion();
            cs = con.prepareCall("call getAllInclusion()");
            rs = cs.executeQuery();
            while (rs.next()) {
                Inclusion inclusion = new Inclusion();
                inclusion.setIdInclusion(rs.getInt(1));
                inclusion.setId_cedula(rs.getInt(2));
                inclusion.setInc_nacionalidad(rs.getString(3));
                inclusion.setInc_embarazo(rs.getString(4));
                inclusion.setInc_mesesembarazo(rs.getString(5));
                inclusion.setInc_licencia(rs.getString(6));
                inclusion.setInc_porcentaje(rs.getString(7));
                lista.add(inclusion);
            }
        } catch (SQLException ex) {
            System.out.println("Error al listar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return lista;
    }

    public Inclusion getById(Integer idInclusion) {
        Inclusion inclusion = null;
        try {
            con = cn.getConexion();
            String query = "SELECT * FROM inclusionlaboral WHERE idINCLUSIONLABORAL=?";
            cs = con.prepareCall(query);
            cs.setInt(1, idInclusion);
            rs = cs.executeQuery();

            if (rs.next()) {
                inclusion = new Inclusion();
                inclusion.setIdInclusion(rs.getInt("idINCLUSIONLABORAL"));
                inclusion.setId_cedula(rs.getInt("id_cedula"));
                inclusion.setInc_nacionalidad(rs.getString("inc_nacionalidad"));
                inclusion.setInc_embarazo(rs.getString("inc_embarazo"));
                inclusion.setInc_mesesembarazo(rs.getString("inc_mesesembarazo"));
                inclusion.setInc_licencia(rs.getString("inc_licencia"));
                inclusion.setInc_porcentaje(rs.getString("inc_porcentaje"));
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener por ID: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return inclusion;
    }

    public Boolean save(Inclusion inclusion) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "INSERT INTO inclusionlaboral (id_cedula, inc_nacionalidad, inc_embarazo, inc_mesesembarazo, inc_licencia, inc_porcentaje) VALUES (?, ?, ?, ?, ?, ?)";
            cs = con.prepareCall(query);
            cs.setInt(1, inclusion.getId_cedula());
            cs.setString(2, inclusion.getInc_nacionalidad());
            cs.setString(3, inclusion.getInc_embarazo());
            cs.setString(4, inclusion.getInc_mesesembarazo());
            cs.setString(5, inclusion.getInc_licencia());
            cs.setString(6, inclusion.getInc_porcentaje());

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean update(Inclusion inclusion) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "UPDATE inclusionlaboral SET id_cedula=?, inc_nacionalidad=?, inc_embarazo=?, inc_mesesembarazo=?, inc_licencia=?, inc_porcentaje=? WHERE idINCLUSIONLABORAL=?";
            cs = con.prepareCall(query);
            cs.setInt(1, inclusion.getId_cedula());
            cs.setString(2, inclusion.getInc_nacionalidad());
            cs.setString(3, inclusion.getInc_embarazo());
            cs.setString(4, inclusion.getInc_mesesembarazo());
            cs.setString(5, inclusion.getInc_licencia());
            cs.setString(6, inclusion.getInc_porcentaje());
            cs.setInt(7, inclusion.getIdInclusion());

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al actualizar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    public Boolean deleteById(Integer idInclusion) {
        boolean success = false;
        try {
            con = cn.getConexion();
            String query = "DELETE FROM inclusionlaboral WHERE idINCLUSIONLABORAL=?";
            cs = con.prepareCall(query);
            cs.setInt(1, idInclusion);

            int rowsAffected = cs.executeUpdate();
            success = (rowsAffected > 0);
        } catch (SQLException ex) {
            System.out.println("Error al eliminar: " + ex.getMessage());
        } finally {
            cerrarRecursos();
        }
        return success;
    }

    private void cerrarRecursos() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (cs != null) {
                cs.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            System.out.println("Error al cerrar recursos: " + ex.getMessage());
        }
    }
}
