package MODELO;

public class Formacion {

    private int idFormacion;
    private int id_cedula;
    private String form_nivelinstruccion;
    private String form_nrocersenecyt;
    private String form_institucioneducativa;
    private String form_añosaprovados;
    private String form_areaconocimiento;
    private String form_egresado_graduado;
    private String form_titulobtenido;
    private String form_pais;

    public Formacion(int idFORMACIONACADEMICA, int id_cedula, String form_nivelinstruccion, String form_nrocersenecyt, String form_institucioneducativa, String form_añosaprovados, String form_areaconocimiento, String form_egresado_graduado, String form_titulobtenido, String form_pais) {
        this.idFormacion = idFORMACIONACADEMICA;
        this.id_cedula = id_cedula;
        this.form_nivelinstruccion = form_nivelinstruccion;
        this.form_nrocersenecyt = form_nrocersenecyt;
        this.form_institucioneducativa = form_institucioneducativa;
        this.form_añosaprovados = form_añosaprovados;
        this.form_areaconocimiento = form_areaconocimiento;
        this.form_egresado_graduado = form_egresado_graduado;
        this.form_titulobtenido = form_titulobtenido;
        this.form_pais = form_pais;
    }

    public Formacion(int id_cedula, String form_nivelinstruccion, String form_nrocersenecyt, String form_institucioneducativa, String form_añosaprovados, String form_areaconocimiento, String form_egresado_graduado, String form_titulobtenido, String form_pais) {
        this.id_cedula = id_cedula;
        this.form_nivelinstruccion = form_nivelinstruccion;
        this.form_nrocersenecyt = form_nrocersenecyt;
        this.form_institucioneducativa = form_institucioneducativa;
        this.form_añosaprovados = form_añosaprovados;
        this.form_areaconocimiento = form_areaconocimiento;
        this.form_egresado_graduado = form_egresado_graduado;
        this.form_titulobtenido = form_titulobtenido;
        this.form_pais = form_pais;
    }

    public Formacion() {
    }

    public int getIdFormacion() {
        return idFormacion;
    }

    public void setIdFormacion(int idFormacion) {
        this.idFormacion = idFormacion;
    }

    public int getId_cedula() {
        return id_cedula;
    }

    public void setId_cedula(int id_cedula) {
        this.id_cedula = id_cedula;
    }

    public String getForm_nivelinstruccion() {
        return form_nivelinstruccion;
    }

    public void setForm_nivelinstruccion(String form_nivelinstruccion) {
        this.form_nivelinstruccion = form_nivelinstruccion;
    }

    public String getForm_nrocersenecyt() {
        return form_nrocersenecyt;
    }

    public void setForm_nrocersenecyt(String form_nrocersenecyt) {
        this.form_nrocersenecyt = form_nrocersenecyt;
    }

    public String getForm_institucioneducativa() {
        return form_institucioneducativa;
    }

    public void setForm_institucioneducativa(String form_institucioneducativa) {
        this.form_institucioneducativa = form_institucioneducativa;
    }

    public String getForm_añosaprovados() {
        return form_añosaprovados;
    }

    public void setForm_añosaprovados(String form_añosaprovados) {
        this.form_añosaprovados = form_añosaprovados;
    }

    public String getForm_areaconocimiento() {
        return form_areaconocimiento;
    }

    public void setForm_areaconocimiento(String form_areaconocimiento) {
        this.form_areaconocimiento = form_areaconocimiento;
    }

    public String getForm_egresado_graduado() {
        return form_egresado_graduado;
    }

    public void setForm_egresado_graduado(String form_egresado_graduado) {
        this.form_egresado_graduado = form_egresado_graduado;
    }

    public String getForm_titulobtenido() {
        return form_titulobtenido;
    }

    public void setForm_titulobtenido(String form_titulobtenido) {
        this.form_titulobtenido = form_titulobtenido;
    }

    public String getForm_pais() {
        return form_pais;
    }

    public void setForm_pais(String form_pais) {
        this.form_pais = form_pais;
    }

    @Override
    public String toString() {
        return "formacionacademica{" + "idFORMACIONACADEMICA=" + idFormacion + ", id_cedula=" + id_cedula + ", form_nivelinstruccion=" + form_nivelinstruccion + ", form_nrocersenecyt=" + form_nrocersenecyt + ", form_institucioneducativa=" + form_institucioneducativa + ", form_a\u00f1osaprovados=" + form_añosaprovados + ", form_areaconocimiento=" + form_areaconocimiento + ", form_egresado_graduado=" + form_egresado_graduado + ", form_titulobtenido=" + form_titulobtenido + ", form_pais=" + form_pais + '}';
    }

}
