package MODELO;

public class Asistencia {

    private int idAsistencia;
    private int id_cedula;
    private String asis_nombredocente;
    private String asis_cargo;
    private String asis_fecha;
    private String asis_horaentrada;
    private String asis_horasalida;
    private String asis_observacion;

    public Asistencia() {
    }

    public Asistencia(int idAsistencia, int id_cedula, String asis_nombredocente, String asis_cargo, String asis_fecha, String asis_horaentrada, String asis_horasalida, String asis_observacion) {
        this.idAsistencia = idAsistencia;
        this.id_cedula = id_cedula;
        this.asis_nombredocente = asis_nombredocente;
        this.asis_cargo = asis_cargo;
        this.asis_fecha = asis_fecha;
        this.asis_horaentrada = asis_horaentrada;
        this.asis_horasalida = asis_horasalida;
        this.asis_observacion = asis_observacion;
    }

    public Asistencia(int id_cedula, String asis_nombredocente, String asis_cargo, String asis_fecha, String asis_horaentrada, String asis_horasalida, String asis_observacion) {
        this.id_cedula = id_cedula;
        this.asis_nombredocente = asis_nombredocente;
        this.asis_cargo = asis_cargo;
        this.asis_fecha = asis_fecha;
        this.asis_horaentrada = asis_horaentrada;
        this.asis_horasalida = asis_horasalida;
        this.asis_observacion = asis_observacion;
    }

    public int getIdAsistencia() {
        return idAsistencia;
    }

    public void setIdAsistencia(int idAsistencia) {
        this.idAsistencia = idAsistencia;
    }

    public int getId_cedula() {
        return id_cedula;
    }

    public void setId_cedula(int id_cedula) {
        this.id_cedula = id_cedula;
    }

    public String getAsis_nombredocente() {
        return asis_nombredocente;
    }

    public void setAsis_nombredocente(String asis_nombredocente) {
        this.asis_nombredocente = asis_nombredocente;
    }

    public String getAsis_cargo() {
        return asis_cargo;
    }

    public void setAsis_cargo(String asis_cargo) {
        this.asis_cargo = asis_cargo;
    }

    public String getAsis_fecha() {
        return asis_fecha;
    }

    public void setAsis_fecha(String asis_fecha) {
        this.asis_fecha = asis_fecha;
    }

    public String getAsis_horaentrada() {
        return asis_horaentrada;
    }

    public void setAsis_horaentrada(String asis_horaentrada) {
        this.asis_horaentrada = asis_horaentrada;
    }

    public String getAsis_horasalida() {
        return asis_horasalida;
    }

    public void setAsis_horasalida(String asis_horasalida) {
        this.asis_horasalida = asis_horasalida;
    }

    public String getAsis_observacion() {
        return asis_observacion;
    }

    public void setAsis_observacion(String asis_observacion) {
        this.asis_observacion = asis_observacion;
    }

    @Override
    public String toString() {
        return "asistencia{" + "idASISTENCIA=" + idAsistencia + ", id_cedula=" + id_cedula + ", asis_nombredocente=" + asis_nombredocente + ", asis_cargo=" + asis_cargo + ", asis_fecha=" + asis_fecha + ", asis_horaentrada=" + asis_horaentrada + ", asis_horasalida=" + asis_horasalida + ", asis_observacion=" + asis_observacion + '}';
    }

}
