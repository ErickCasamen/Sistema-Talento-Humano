package MODELO;

public class capacitacion {

    private int idCapacitacion;
    private int id_cedula;
    private String cap_nombreevento;
    private String cap_tipo;
    private String cap_auspiciante;
    private String cap_horas;
    private String cap_tipocertificado;
    private String cap_institucion;
    private String cap_fechainicio;
    private String cap_fechafinal;

    public capacitacion() {
    }

    public capacitacion(int idCapacitacion, int id_cedula, String cap_nombreevento, String cap_tipo, String cap_auspiciante, String cap_horas, String cap_tipocertificado, String cap_institucion, String cap_fechainicio, String cap_fechafinal) {
        this.idCapacitacion = idCapacitacion;
        this.id_cedula = id_cedula;
        this.cap_nombreevento = cap_nombreevento;
        this.cap_tipo = cap_tipo;
        this.cap_auspiciante = cap_auspiciante;
        this.cap_horas = cap_horas;
        this.cap_tipocertificado = cap_tipocertificado;
        this.cap_institucion = cap_institucion;
        this.cap_fechainicio = cap_fechainicio;
        this.cap_fechafinal = cap_fechafinal;
    }

    public capacitacion(int id_cedula, String cap_nombreevento, String cap_tipo, String cap_auspiciante, String cap_horas, String cap_tipocertificado, String cap_institucion, String cap_fechainicio, String cap_fechafinal) {
        this.id_cedula = id_cedula;
        this.cap_nombreevento = cap_nombreevento;
        this.cap_tipo = cap_tipo;
        this.cap_auspiciante = cap_auspiciante;
        this.cap_horas = cap_horas;
        this.cap_tipocertificado = cap_tipocertificado;
        this.cap_institucion = cap_institucion;
        this.cap_fechainicio = cap_fechainicio;
        this.cap_fechafinal = cap_fechafinal;
    }

    public int getIdCapacitacion() {
        return idCapacitacion;
    }

    public void setIdCapacitacion(int idCapacitacion) {
        this.idCapacitacion = idCapacitacion;
    }

    public int getId_cedula() {
        return id_cedula;
    }

    public void setId_cedula(int id_cedula) {
        this.id_cedula = id_cedula;
    }

    public String getCap_nombreevento() {
        return cap_nombreevento;
    }

    public void setCap_nombreevento(String cap_nombreevento) {
        this.cap_nombreevento = cap_nombreevento;
    }

    public String getCap_tipo() {
        return cap_tipo;
    }

    public void setCap_tipo(String cap_tipo) {
        this.cap_tipo = cap_tipo;
    }

    public String getCap_auspiciante() {
        return cap_auspiciante;
    }

    public void setCap_auspiciante(String cap_auspiciante) {
        this.cap_auspiciante = cap_auspiciante;
    }

    public String getCap_horas() {
        return cap_horas;
    }

    public void setCap_horas(String cap_horas) {
        this.cap_horas = cap_horas;
    }

    public String getCap_tipocertificado() {
        return cap_tipocertificado;
    }

    public void setCap_tipocertificado(String cap_tipocertificado) {
        this.cap_tipocertificado = cap_tipocertificado;
    }

    public String getCap_institucion() {
        return cap_institucion;
    }

    public void setCap_institucion(String cap_institucion) {
        this.cap_institucion = cap_institucion;
    }

    public String getCap_fechainicio() {
        return cap_fechainicio;
    }

    public void setCap_fechainicio(String cap_fechainicio) {
        this.cap_fechainicio = cap_fechainicio;
    }

    public String getCap_fechafinal() {
        return cap_fechafinal;
    }

    public void setCap_fechafinal(String cap_fechafinal) {
        this.cap_fechafinal = cap_fechafinal;
    }

    @Override
    public String toString() {
        return "capacitacion{" + "idCapacitacion=" + idCapacitacion + ", id_cedula=" + id_cedula + ", cap_nombreevento=" + cap_nombreevento + ", cap_tipo=" + cap_tipo + ", cap_auspiciante=" + cap_auspiciante + ", cap_horas=" + cap_horas + ", cap_tipocertificado=" + cap_tipocertificado + ", cap_institucion=" + cap_institucion + ", cap_fechainicio=" + cap_fechainicio + ", cap_fechafinal=" + cap_fechafinal + '}';
    }

}
