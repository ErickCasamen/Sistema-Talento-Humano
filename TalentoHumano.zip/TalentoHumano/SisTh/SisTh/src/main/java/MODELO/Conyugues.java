package MODELO;

public class Conyugues {

    private int idConyugue;
    private int id_cedula;
    private String cony_tiporelacion;
    private String cony_cedula;
    private String cony_apellidos;
    private String cony_nombres;

    public Conyugues() {
   
    }

    public Conyugues(int idCONYUGUE, int id_cedula, String cony_tiporelacion, String cony_cedula, String cony_apellidos, String cony_nombres) {
        this.idConyugue = idCONYUGUE;
        this.id_cedula = id_cedula;
        this.cony_tiporelacion = cony_tiporelacion;
        this.cony_cedula = cony_cedula;
        this.cony_apellidos = cony_apellidos;
        this.cony_nombres = cony_nombres;
    }

    public Conyugues(int id_cedula, String cony_tiporelacion, String cony_cedula, String cony_apellidos, String cony_nombres) {
        this.id_cedula = id_cedula;
        this.cony_tiporelacion = cony_tiporelacion;
        this.cony_cedula = cony_cedula;
        this.cony_apellidos = cony_apellidos;
        this.cony_nombres = cony_nombres;
    }

    public int getIdConyugue() {
        return idConyugue;
    }

    public void setIdConyugue(int idConyugue) {
        this.idConyugue = idConyugue;
    }

    public int getId_cedula() {
        return id_cedula;
    }

    public void setId_cedula(int id_cedula) {
        this.id_cedula = id_cedula;
    }

    public String getCony_tiporelacion() {
        return cony_tiporelacion;
    }

    public void setCony_tiporelacion(String cony_tiporelacion) {
        this.cony_tiporelacion = cony_tiporelacion;
    }

    public String getCony_cedula() {
        return cony_cedula;
    }

    public void setCony_cedula(String cony_cedula) {
        this.cony_cedula = cony_cedula;
    }

    public String getCony_apellidos() {
        return cony_apellidos;
    }

    public void setCony_apellidos(String cony_apellidos) {
        this.cony_apellidos = cony_apellidos;
    }

    public String getCony_nombres() {
        return cony_nombres;
    }

    public void setCony_nombres(String cony_nombres) {
        this.cony_nombres = cony_nombres;
    }

    @Override
    public String toString() {
        return "conyugue{" + "idCONYUGUE=" + idConyugue + ", id_cedula=" + id_cedula + ", cony_tiporelacion=" + cony_tiporelacion + ", cony_cedula=" + cony_cedula + ", cony_apellidos=" + cony_apellidos + ", cony_nombres=" + cony_nombres + '}';
    }

    
}
