package MODELO;

public class Emergencias {

    private int idEmergencia;
    private int idCedula;
    private String contNombres;
    private String contApellidos;
    private String contTelefono;

    public Emergencias(int idCONTACTOEMERGENCIA, int id_cedula, String cont_nombres, String cont_apellidos, String cont_telefono) {
        this.idEmergencia = idCONTACTOEMERGENCIA;
        this.idCedula = id_cedula;
        this.contNombres = cont_nombres;
        this.contApellidos = cont_apellidos;
        this.contTelefono = cont_telefono;
    }

    public Emergencias(int id_cedula, String cont_nombres, String cont_apellidos, String cont_telefono) {
        this.idCedula = id_cedula;
        this.contNombres = cont_nombres;
        this.contApellidos = cont_apellidos;
        this.contTelefono = cont_telefono;
    }

    public Emergencias() {
    }
    
  
 

    public int getIdEmergencia() {
        return idEmergencia;
    }

    public void setIdEmergencia(int idEmergencia) {
        this.idEmergencia = idEmergencia;
    }

    public int getIdCedula() {
        return idCedula;
    }

    public void setIdCedula(int idCedula) {
        this.idCedula = idCedula;
    }

    public String getContNombres() {
        return contNombres;
    }

    public void setContNombres(String contNombres) {
        this.contNombres = contNombres;
    }

    public String getContApellidos() {
        return contApellidos;
    }

    public void setContApellidos(String contApellidos) {
        this.contApellidos = contApellidos;
    }

    public String getContTelefono() {
        return contTelefono;
    }

    public void setContTelefono(String contTelefono) {
        this.contTelefono = contTelefono;
    }

    @Override
    public String toString() {
        return "contactoemergencia{" + "idCONTACTOEMERGENCIA=" + idEmergencia + ", id_cedula=" + idCedula + ", cont_nombres=" + contNombres + ", cont_apellidos=" + contApellidos + ", cont_telefono=" + contTelefono + '}';
    }

    

}
