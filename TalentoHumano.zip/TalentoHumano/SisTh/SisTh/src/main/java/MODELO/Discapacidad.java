package MODELO;

public class Discapacidad {

    private int idDiscapacidad;
    private int id_cedula;
    private String disc_situacion;
    private String disc_tiporelacion;
    private String disc_nroconadis;
    private String disc_certificiado_enfermedad;
    private String disc_tipodiscapacidad;
    private String disc_porcentaje;
    private String disc_tipoenfermedad;

    public Discapacidad() {
    }

    
    public Discapacidad(int idDISCAPACIDAD, int id_cedula, String disc_situacion, String disc_tiporelacion, String disc_nroconadis, String disc_certificiado_enfermedad, String disc_tipodiscapacidad, String disc_porcentaje, String disc_tipoenfermedad) {
        this.idDiscapacidad = idDISCAPACIDAD;
        this.id_cedula = id_cedula;
        this.disc_situacion = disc_situacion;
        this.disc_tiporelacion = disc_tiporelacion;
        this.disc_nroconadis = disc_nroconadis;
        this.disc_certificiado_enfermedad = disc_certificiado_enfermedad;
        this.disc_tipodiscapacidad = disc_tipodiscapacidad;
        this.disc_porcentaje = disc_porcentaje;
        this.disc_tipoenfermedad = disc_tipoenfermedad;
    }

    public Discapacidad(int id_cedula, String disc_situacion, String disc_tiporelacion, String disc_nroconadis, String disc_certificiado_enfermedad, String disc_tipodiscapacidad, String disc_porcentaje, String disc_tipoenfermedad) {
        this.id_cedula = id_cedula;
        this.disc_situacion = disc_situacion;
        this.disc_tiporelacion = disc_tiporelacion;
        this.disc_nroconadis = disc_nroconadis;
        this.disc_certificiado_enfermedad = disc_certificiado_enfermedad;
        this.disc_tipodiscapacidad = disc_tipodiscapacidad;
        this.disc_porcentaje = disc_porcentaje;
        this.disc_tipoenfermedad = disc_tipoenfermedad;
    }

    public Discapacidad(int aInt, int aInt0, String string, String string0, String string1, String string2) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getIdDiscapacidad() {
        return idDiscapacidad;
    }

    public void setIdDiscapacidad(int idDiscapacidad) {
        this.idDiscapacidad = idDiscapacidad;
    }

    public int getId_cedula() {
        return id_cedula;
    }

    public void setId_cedula(int id_cedula) {
        this.id_cedula = id_cedula;
    }

    public String getDisc_situacion() {
        return disc_situacion;
    }

    public void setDisc_situacion(String disc_situacion) {
        this.disc_situacion = disc_situacion;
    }

    public String getDisc_tiporelacion() {
        return disc_tiporelacion;
    }

    public void setDisc_tiporelacion(String disc_tiporelacion) {
        this.disc_tiporelacion = disc_tiporelacion;
    }

    public String getDisc_nroconadis() {
        return disc_nroconadis;
    }

    public void setDisc_nroconadis(String disc_nroconadis) {
        this.disc_nroconadis = disc_nroconadis;
    }

    public String getDisc_certificiado_enfermedad() {
        return disc_certificiado_enfermedad;
    }

    public void setDisc_certificiado_enfermedad(String disc_certificiado_enfermedad) {
        this.disc_certificiado_enfermedad = disc_certificiado_enfermedad;
    }

    public String getDisc_tipodiscapacidad() {
        return disc_tipodiscapacidad;
    }

    public void setDisc_tipodiscapacidad(String disc_tipodiscapacidad) {
        this.disc_tipodiscapacidad = disc_tipodiscapacidad;
    }

    public String getDisc_porcentaje() {
        return disc_porcentaje;
    }

    public void setDisc_porcentaje(String disc_porcentaje) {
        this.disc_porcentaje = disc_porcentaje;
    }

    public String getDisc_tipoenfermedad() {
        return disc_tipoenfermedad;
    }

    public void setDisc_tipoenfermedad(String disc_tipoenfermedad) {
        this.disc_tipoenfermedad = disc_tipoenfermedad;
    }

    @Override
    public String toString() {
        return "discapacidad{" + "idDISCAPACIDAD=" + idDiscapacidad + ", id_cedula=" + id_cedula + ", disc_situacion=" + disc_situacion + ", disc_tiporelacion=" + disc_tiporelacion + ", disc_nroconadis=" + disc_nroconadis + ", disc_certificiado_enfermedad=" + disc_certificiado_enfermedad + ", disc_tipodiscapacidad=" + disc_tipodiscapacidad + ", disc_porcentaje=" + disc_porcentaje + ", disc_tipoenfermedad=" + disc_tipoenfermedad + '}';
    }

   
}
