
package MODELO;

public class Login {

    private final int intentosMaximos = 3;
    private int limiteIntentos = 0;
    private String user = "Damian";
    private String password = "000";

    public Login() {
    }

    public String getUser() {
        return user;
    }

    public void setUser(String username) {
        this.user = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean validarUsuario(String enteredUsername, String enteredPassword) {
        System.out.println("Entered Username: " + enteredUsername);
        System.out.println("Entered Password: " + enteredPassword);

        //controlamos los intentos 
        if (limiteIntentos >= intentosMaximos) {
            System.out.println(" Su Cuenta esta bloqueada ");
            return false;
            // Cuenta Bloqueada
        }
        //validamos el usuario 
        boolean usuvalido = user.equals(enteredUsername) && password.equals(enteredPassword);

        if (usuvalido) {
            System.out.println("Autenticación exitosa. Reiniciando oportunidades.");
            // Credenciales correctas
            resetAttempts();
        } else {
            //maximo de intentos
            System.out.println("Intentos por agotar:" + (intentosMaximos - limiteIntentos));
            limiteIntentos++;
        }

        return usuvalido;
    }

    public void resetAttempts() {
        limiteIntentos = 0;
    }

    public int getRemainingAttempts() {
        return intentosMaximos - limiteIntentos;
    }
}
