package MODELO;

public class Informacion {

    private int idInformacion;
    private int id_cedula;
    private String inf_insfinanciera;
    private String inf_tipocuenta;
    private String inf_nrocuenta;

    public Informacion(int idINFORMACIONBANCARIA, int id_cedula, String inf_insfinanciera, String inf_tipocuenta, String inf_nrocuenta) {
        this.idInformacion = idINFORMACIONBANCARIA;
        this.id_cedula = id_cedula;
        this.inf_insfinanciera = inf_insfinanciera;
        this.inf_tipocuenta = inf_tipocuenta;
        this.inf_nrocuenta = inf_nrocuenta;
    }

    public Informacion(int id_cedula, String inf_insfinanciera, String inf_tipocuenta, String inf_nrocuenta) {
        this.id_cedula = id_cedula;
        this.inf_insfinanciera = inf_insfinanciera;
        this.inf_tipocuenta = inf_tipocuenta;
        this.inf_nrocuenta = inf_nrocuenta;
    }

    public Informacion() {
    }

    public int getIdInformacion() {
        return idInformacion;
    }

    public void setIdInformacion(int idInformacion) {
        this.idInformacion = idInformacion;
    }

    public int getId_cedula() {
        return id_cedula;
    }

    public void setId_cedula(int id_cedula) {
        this.id_cedula = id_cedula;
    }

    public String getInf_insfinanciera() {
        return inf_insfinanciera;
    }

    public void setInf_insfinanciera(String inf_insfinanciera) {
        this.inf_insfinanciera = inf_insfinanciera;
    }

    public String getInf_tipocuenta() {
        return inf_tipocuenta;
    }

    public void setInf_tipocuenta(String inf_tipocuenta) {
        this.inf_tipocuenta = inf_tipocuenta;
    }

    public String getInf_nrocuenta() {
        return inf_nrocuenta;
    }

    public void setInf_nrocuenta(String inf_nrocuenta) {
        this.inf_nrocuenta = inf_nrocuenta;
    }

    @Override
    public String toString() {
        return "informacionbancaria{" + "idINFORMACIONBANCARIA=" + idInformacion + ", id_cedula=" + id_cedula + ", inf_insfinanciera=" + inf_insfinanciera + ", inf_tipocuenta=" + inf_tipocuenta + ", inf_nrocuenta=" + inf_nrocuenta + '}';
    }

}
