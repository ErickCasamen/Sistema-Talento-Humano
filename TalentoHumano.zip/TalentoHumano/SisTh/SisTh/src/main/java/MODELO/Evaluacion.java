package MODELO;

public class Evaluacion {

    private int idEvaluacion;
    private int id_cedula;
    private String eva_periodoinicio;
    private String eva_periodohasta;
    private String eva_nombre;
    private String eva_puntaje;
    private String eva_calificacion;
    private String eva_observacion;

    public Evaluacion(int idEVALUACION, int id_cedula, String eva_periodoinicio, String eva_periodohasta, String eva_nombre, String eva_puntaje, String eva_calificacion, String eva_observacion) {
        this.idEvaluacion = idEVALUACION;
        this.id_cedula = id_cedula;
        this.eva_periodoinicio = eva_periodoinicio;
        this.eva_periodohasta = eva_periodohasta;
        this.eva_nombre = eva_nombre;
        this.eva_puntaje = eva_puntaje;
        this.eva_calificacion = eva_calificacion;
        this.eva_observacion = eva_observacion;
    }

    public Evaluacion(int id_cedula, String eva_periodoinicio, String eva_periodohasta, String eva_nombre, String eva_puntaje, String eva_calificacion, String eva_observacion) {
        this.id_cedula = id_cedula;
        this.eva_periodoinicio = eva_periodoinicio;
        this.eva_periodohasta = eva_periodohasta;
        this.eva_nombre = eva_nombre;
        this.eva_puntaje = eva_puntaje;
        this.eva_calificacion = eva_calificacion;
        this.eva_observacion = eva_observacion;
    }

    public Evaluacion() {
    }

    public int getIdEvaluacion() {
        return idEvaluacion;
    }

    public void setIdEvaluacion(int idEvaluacion) {
        this.idEvaluacion = idEvaluacion;
    }

    public int getId_cedula() {
        return id_cedula;
    }

    public void setId_cedula(int id_cedula) {
        this.id_cedula = id_cedula;
    }

    public String getEva_periodoinicio() {
        return eva_periodoinicio;
    }

    public void setEva_periodoinicio(String eva_periodoinicio) {
        this.eva_periodoinicio = eva_periodoinicio;
    }

    public String getEva_periodohasta() {
        return eva_periodohasta;
    }

    public void setEva_periodohasta(String eva_periodohasta) {
        this.eva_periodohasta = eva_periodohasta;
    }

    public String getEva_nombre() {
        return eva_nombre;
    }

    public void setEva_nombre(String eva_nombre) {
        this.eva_nombre = eva_nombre;
    }

    public String getEva_puntaje() {
        return eva_puntaje;
    }

    public void setEva_puntaje(String eva_puntaje) {
        this.eva_puntaje = eva_puntaje;
    }

    public String getEva_calificacion() {
        return eva_calificacion;
    }

    public void setEva_calificacion(String eva_calificacion) {
        this.eva_calificacion = eva_calificacion;
    }

    public String getEva_observacion() {
        return eva_observacion;
    }

    public void setEva_observacion(String eva_observacion) {
        this.eva_observacion = eva_observacion;
    }

    @Override
    public String toString() {
        return "evaluacion{" + "idEVALUACION=" + idEvaluacion + ", id_cedula=" + id_cedula + ", eva_periodoinicio=" + eva_periodoinicio + ", eva_periodohasta=" + eva_periodohasta + ", eva_nombre=" + eva_nombre + ", eva_puntaje=" + eva_puntaje + ", eva_calificacion=" + eva_calificacion + ", eva_observacion=" + eva_observacion + '}';
    }

}
