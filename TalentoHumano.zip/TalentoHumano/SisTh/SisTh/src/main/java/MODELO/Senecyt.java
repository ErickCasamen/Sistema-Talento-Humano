package MODELO;

public class Senecyt {

    private int idSenecyt;
    private int id_cedula;
    private String sis_fechaingreso;
    private String sis_fechasalida;
    private String sis_unidad;
    private String sis_modalidad;
    private String sis_grupocupacional;
    private String sis_puesto;

    public Senecyt(int idSENECYT, int id_cedula, String sis_fechaingreso, String sis_fechasalida, String sis_unidad, String sis_modalidad, String sis_grupocupacional, String sis_puesto) {
        this.idSenecyt = idSENECYT;
        this.id_cedula = id_cedula;
        this.sis_fechaingreso = sis_fechaingreso;
        this.sis_fechasalida = sis_fechasalida;
        this.sis_unidad = sis_unidad;
        this.sis_modalidad = sis_modalidad;
        this.sis_grupocupacional = sis_grupocupacional;
        this.sis_puesto = sis_puesto;
    }

    public Senecyt(int id_cedula, String sis_fechaingreso, String sis_fechasalida, String sis_unidad, String sis_modalidad, String sis_grupocupacional, String sis_puesto) {
        this.id_cedula = id_cedula;
        this.sis_fechaingreso = sis_fechaingreso;
        this.sis_fechasalida = sis_fechasalida;
        this.sis_unidad = sis_unidad;
        this.sis_modalidad = sis_modalidad;
        this.sis_grupocupacional = sis_grupocupacional;
        this.sis_puesto = sis_puesto;
    }

    public Senecyt() {
    }

    public int getIdSenecyt() {
        return idSenecyt;
    }

    public void setIdSenecyt(int idSenecyt) {
        this.idSenecyt = idSenecyt;
    }

    public int getId_cedula() {
        return id_cedula;
    }

    public void setId_cedula(int id_cedula) {
        this.id_cedula = id_cedula;
    }

    public String getSis_fechaingreso() {
        return sis_fechaingreso;
    }

    public void setSis_fechaingreso(String sis_fechaingreso) {
        this.sis_fechaingreso = sis_fechaingreso;
    }

    public String getSis_fechasalida() {
        return sis_fechasalida;
    }

    public void setSis_fechasalida(String sis_fechasalida) {
        this.sis_fechasalida = sis_fechasalida;
    }

    public String getSis_unidad() {
        return sis_unidad;
    }

    public void setSis_unidad(String sis_unidad) {
        this.sis_unidad = sis_unidad;
    }

    public String getSis_modalidad() {
        return sis_modalidad;
    }

    public void setSis_modalidad(String sis_modalidad) {
        this.sis_modalidad = sis_modalidad;
    }

    public String getSis_grupocupacional() {
        return sis_grupocupacional;
    }

    public void setSis_grupocupacional(String sis_grupocupacional) {
        this.sis_grupocupacional = sis_grupocupacional;
    }

    public String getSis_puesto() {
        return sis_puesto;
    }

    public void setSis_puesto(String sis_puesto) {
        this.sis_puesto = sis_puesto;
    }

    @Override
    public String toString() {
        return "senecyt{" + "idSENECYT=" + idSenecyt + ", id_cedula=" + id_cedula + ", sis_fechaingreso=" + sis_fechaingreso + ", sis_fechasalida=" + sis_fechasalida + ", sis_unidad=" + sis_unidad + ", sis_modalidad=" + sis_modalidad + ", sis_grupocupacional=" + sis_grupocupacional + ", sis_puesto=" + sis_puesto + '}';
    }

}
