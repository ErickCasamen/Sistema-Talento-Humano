package MODELO;

public class Permiso {

    private int idPermiso;
    private int id_cedula;
    private String per_fecha;
    private String per_provincia;
    private String per_regimen;
    private String per_Apellidos;
    private String per_Nombres;
    private String per_cedula;
    private String per_cordinacionzonal;
    private String per_direccionunidad;
    private String per_motivo;
    private String per_horas;
    private String per_dias;
    private String per_valordescontar;

    public Permiso(int idPERMISOS, int id_cedula, String per_fecha, String per_provincia, String per_regimen, String per_Apellidos, String per_Nombres, String per_cedula, String per_cordinacionzonal, String per_direccionunidad, String per_motivo, String per_horas, String per_dias, String per_valordescontar) {
        this.idPermiso = idPERMISOS;
        this.id_cedula = id_cedula;
        this.per_fecha = per_fecha;
        this.per_provincia = per_provincia;
        this.per_regimen = per_regimen;
        this.per_Apellidos = per_Apellidos;
        this.per_Nombres = per_Nombres;
        this.per_cedula = per_cedula;
        this.per_cordinacionzonal = per_cordinacionzonal;
        this.per_direccionunidad = per_direccionunidad;
        this.per_motivo = per_motivo;
        this.per_horas = per_horas;
        this.per_dias = per_dias;
        this.per_valordescontar = per_valordescontar;
    }

    public Permiso(int id_cedula, String per_fecha, String per_provincia, String per_regimen, String per_Apellidos, String per_Nombres, String per_cedula, String per_cordinacionzonal, String per_direccionunidad, String per_motivo, String per_horas, String per_dias, String per_valordescontar) {
        this.id_cedula = id_cedula;
        this.per_fecha = per_fecha;
        this.per_provincia = per_provincia;
        this.per_regimen = per_regimen;
        this.per_Apellidos = per_Apellidos;
        this.per_Nombres = per_Nombres;
        this.per_cedula = per_cedula;
        this.per_cordinacionzonal = per_cordinacionzonal;
        this.per_direccionunidad = per_direccionunidad;
        this.per_motivo = per_motivo;
        this.per_horas = per_horas;
        this.per_dias = per_dias;
        this.per_valordescontar = per_valordescontar;
    }

    public Permiso() {
    }

    public int getIdPermiso() {
        return idPermiso;
    }

    public void setIdPermiso(int idPermiso) {
        this.idPermiso = idPermiso;
    }

    public int getId_cedula() {
        return id_cedula;
    }

    public void setId_cedula(int id_cedula) {
        this.id_cedula = id_cedula;
    }

    public String getPer_fecha() {
        return per_fecha;
    }

    public void setPer_fecha(String per_fecha) {
        this.per_fecha = per_fecha;
    }

    public String getPer_provincia() {
        return per_provincia;
    }

    public void setPer_provincia(String per_provincia) {
        this.per_provincia = per_provincia;
    }

    public String getPer_regimen() {
        return per_regimen;
    }

    public void setPer_regimen(String per_regimen) {
        this.per_regimen = per_regimen;
    }

    public String getPer_Apellidos() {
        return per_Apellidos;
    }

    public void setPer_Apellidos(String per_Apellidos) {
        this.per_Apellidos = per_Apellidos;
    }

    public String getPer_Nombres() {
        return per_Nombres;
    }

    public void setPer_Nombres(String per_Nombres) {
        this.per_Nombres = per_Nombres;
    }

    public String getPer_cedula() {
        return per_cedula;
    }

    public void setPer_cedula(String per_cedula) {
        this.per_cedula = per_cedula;
    }

    public String getPer_cordinacionzonal() {
        return per_cordinacionzonal;
    }

    public void setPer_cordinacionzonal(String per_cordinacionzonal) {
        this.per_cordinacionzonal = per_cordinacionzonal;
    }

    public String getPer_direccionunidad() {
        return per_direccionunidad;
    }

    public void setPer_direccionunidad(String per_direccionunidad) {
        this.per_direccionunidad = per_direccionunidad;
    }

    public String getPer_motivo() {
        return per_motivo;
    }

    public void setPer_motivo(String per_motivo) {
        this.per_motivo = per_motivo;
    }

    public String getPer_horas() {
        return per_horas;
    }

    public void setPer_horas(String per_horas) {
        this.per_horas = per_horas;
    }

    public String getPer_dias() {
        return per_dias;
    }

    public void setPer_dias(String per_dias) {
        this.per_dias = per_dias;
    }

    public String getPer_valordescontar() {
        return per_valordescontar;
    }

    public void setPer_valordescontar(String per_valordescontar) {
        this.per_valordescontar = per_valordescontar;
    }

    @Override
    public String toString() {
        return "permiso{" + "idPERMISOS=" + idPermiso + ", id_cedula=" + id_cedula + ", per_fecha=" + per_fecha + ", per_provincia=" + per_provincia + ", per_regimen=" + per_regimen + ", per_Apellidos=" + per_Apellidos + ", per_Nombres=" + per_Nombres + ", per_cedula=" + per_cedula + ", per_cordinacionzonal=" + per_cordinacionzonal + ", per_direccionunidad=" + per_direccionunidad + ", per_motivo=" + per_motivo + ", per_horas=" + per_horas + ", per_dias=" + per_dias + ", per_valordescontar=" + per_valordescontar + '}';
    }

}
