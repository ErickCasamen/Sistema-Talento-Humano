package MODELO;

public class Trayectoria {

    private int idTrayectoria;
    private int id_cedula;
    private String tray_institucion;
    private String tray_organizacionnombre;
    private String tray_unidadadministrativa;
    private String tray_denominacionpuesto;
    private String tray_fechaingreso;
    private String tray_fechasalida;
    private String tray_tipoingreso;
    private String tray_motivosalida;

    public Trayectoria(int idTRAYECTORIALABORAL, int id_cedula, String tray_institucion, String tray_organizacionnombre, String tray_unidadadministrativa, String tray_denominacionpuesto, String tray_fechaingreso, String tray_fechasalida, String tray_tipoingreso, String tray_motivosalida) {
        this.idTrayectoria = idTRAYECTORIALABORAL;
        this.id_cedula = id_cedula;
        this.tray_institucion = tray_institucion;
        this.tray_organizacionnombre = tray_organizacionnombre;
        this.tray_unidadadministrativa = tray_unidadadministrativa;
        this.tray_denominacionpuesto = tray_denominacionpuesto;
        this.tray_fechaingreso = tray_fechaingreso;
        this.tray_fechasalida = tray_fechasalida;
        this.tray_tipoingreso = tray_tipoingreso;
        this.tray_motivosalida = tray_motivosalida;
    }

    public Trayectoria(int id_cedula, String tray_institucion, String tray_organizacionnombre, String tray_unidadadministrativa, String tray_denominacionpuesto, String tray_fechaingreso, String tray_fechasalida, String tray_tipoingreso, String tray_motivosalida) {
        this.id_cedula = id_cedula;
        this.tray_institucion = tray_institucion;
        this.tray_organizacionnombre = tray_organizacionnombre;
        this.tray_unidadadministrativa = tray_unidadadministrativa;
        this.tray_denominacionpuesto = tray_denominacionpuesto;
        this.tray_fechaingreso = tray_fechaingreso;
        this.tray_fechasalida = tray_fechasalida;
        this.tray_tipoingreso = tray_tipoingreso;
        this.tray_motivosalida = tray_motivosalida;
    }

    public Trayectoria() {
    }

    public int getIdTrayectoria() {
        return idTrayectoria;
    }

    public void setIdTrayectoria(int idTrayectoria) {
        this.idTrayectoria = idTrayectoria;
    }

    public int getId_cedula() {
        return id_cedula;
    }

    public void setId_cedula(int id_cedula) {
        this.id_cedula = id_cedula;
    }

    public String getTray_institucion() {
        return tray_institucion;
    }

    public void setTray_institucion(String tray_institucion) {
        this.tray_institucion = tray_institucion;
    }

    public String getTray_organizacionnombre() {
        return tray_organizacionnombre;
    }

    public void setTray_organizacionnombre(String tray_organizacionnombre) {
        this.tray_organizacionnombre = tray_organizacionnombre;
    }

    public String getTray_unidadadministrativa() {
        return tray_unidadadministrativa;
    }

    public void setTray_unidadadministrativa(String tray_unidadadministrativa) {
        this.tray_unidadadministrativa = tray_unidadadministrativa;
    }

    public String getTray_denominacionpuesto() {
        return tray_denominacionpuesto;
    }

    public void setTray_denominacionpuesto(String tray_denominacionpuesto) {
        this.tray_denominacionpuesto = tray_denominacionpuesto;
    }

    public String getTray_fechaingreso() {
        return tray_fechaingreso;
    }

    public void setTray_fechaingreso(String tray_fechaingreso) {
        this.tray_fechaingreso = tray_fechaingreso;
    }

    public String getTray_fechasalida() {
        return tray_fechasalida;
    }

    public void setTray_fechasalida(String tray_fechasalida) {
        this.tray_fechasalida = tray_fechasalida;
    }

    public String getTray_tipoingreso() {
        return tray_tipoingreso;
    }

    public void setTray_tipoingreso(String tray_tipoingreso) {
        this.tray_tipoingreso = tray_tipoingreso;
    }

    public String getTray_motivosalida() {
        return tray_motivosalida;
    }

    public void setTray_motivosalida(String tray_motivosalida) {
        this.tray_motivosalida = tray_motivosalida;
    }

    @Override
    public String toString() {
        return "trayectorialaboral{" + "idTRAYECTORIALABORAL=" + idTrayectoria + ", id_cedula=" + id_cedula + ", tray_institucion=" + tray_institucion + ", tray_organizacionnombre=" + tray_organizacionnombre + ", tray_unidadadministrativa=" + tray_unidadadministrativa + ", tray_denominacionpuesto=" + tray_denominacionpuesto + ", tray_fechaingreso=" + tray_fechaingreso + ", tray_fechasalida=" + tray_fechasalida + ", tray_tipoingreso=" + tray_tipoingreso + ", tray_motivosalida=" + tray_motivosalida + '}';
    }

}