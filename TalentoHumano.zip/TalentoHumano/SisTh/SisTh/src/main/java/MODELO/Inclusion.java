package MODELO;

public class Inclusion {

    private int idInclusion;
    private int id_cedula;
    private String inc_nacionalidad;
    private String inc_embarazo;
    private String inc_mesesembarazo;
    private String inc_licencia;
    private String inc_porcentaje;

    public Inclusion(int idINCLUSIONLABORAL, int id_cedula, String inc_nacionalidad, String inc_embarazo, String inc_mesesembarazo, String inc_licencia, String inc_porcentaje) {
        this.idInclusion = idINCLUSIONLABORAL;
        this.id_cedula = id_cedula;
        this.inc_nacionalidad = inc_nacionalidad;
        this.inc_embarazo = inc_embarazo;
        this.inc_mesesembarazo = inc_mesesembarazo;
        this.inc_licencia = inc_licencia;
        this.inc_porcentaje = inc_porcentaje;
    }

    public Inclusion(int id_cedula, String inc_nacionalidad, String inc_embarazo, String inc_mesesembarazo, String inc_licencia, String inc_porcentaje) {
        this.id_cedula = id_cedula;
        this.inc_nacionalidad = inc_nacionalidad;
        this.inc_embarazo = inc_embarazo;
        this.inc_mesesembarazo = inc_mesesembarazo;
        this.inc_licencia = inc_licencia;
        this.inc_porcentaje = inc_porcentaje;
    }

    public Inclusion() {
    }

    public int getIdInclusion() {
        return idInclusion;
    }

    public void setIdInclusion(int idInclusion) {
        this.idInclusion = idInclusion;
    }

    public int getId_cedula() {
        return id_cedula;
    }

    public void setId_cedula(int id_cedula) {
        this.id_cedula = id_cedula;
    }

    public String getInc_nacionalidad() {
        return inc_nacionalidad;
    }

    public void setInc_nacionalidad(String inc_nacionalidad) {
        this.inc_nacionalidad = inc_nacionalidad;
    }

    public String getInc_embarazo() {
        return inc_embarazo;
    }

    public void setInc_embarazo(String inc_embarazo) {
        this.inc_embarazo = inc_embarazo;
    }

    public String getInc_mesesembarazo() {
        return inc_mesesembarazo;
    }

    public void setInc_mesesembarazo(String inc_mesesembarazo) {
        this.inc_mesesembarazo = inc_mesesembarazo;
    }

    public String getInc_licencia() {
        return inc_licencia;
    }

    public void setInc_licencia(String inc_licencia) {
        this.inc_licencia = inc_licencia;
    }

    public String getInc_porcentaje() {
        return inc_porcentaje;
    }

    public void setInc_porcentaje(String inc_porcentaje) {
        this.inc_porcentaje = inc_porcentaje;
    }

    @Override
    public String toString() {
        return "inclusionlaboral{" + "idINCLUSIONLABORAL=" + idInclusion + ", id_cedula=" + id_cedula + ", inc_nacionalidad=" + inc_nacionalidad + ", inc_embarazo=" + inc_embarazo + ", inc_mesesembarazo=" + inc_mesesembarazo + ", inc_licencia=" + inc_licencia + ", inc_porcentaje=" + inc_porcentaje + '}';
    }

}
