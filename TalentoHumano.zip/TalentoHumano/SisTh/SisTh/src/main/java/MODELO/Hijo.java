package MODELO;

public class Hijo {

    private int idHIJOS;
    private int id_cedula;
    private String hi_cedula;
    private String hi_nombres;
    private String hi_apellidos;
    private String hi_nivelinstitucional;

    public Hijo(int idHIJOS, int id_cedula, String hi_cedula, String hi_nombres, String hi_apellidos, String hi_nivelinstitucional) {
        this.idHIJOS = idHIJOS;
        this.id_cedula = id_cedula;
        this.hi_cedula = hi_cedula;
        this.hi_nombres = hi_nombres;
        this.hi_apellidos = hi_apellidos;
        this.hi_nivelinstitucional = hi_nivelinstitucional;
    }

    public Hijo(int id_cedula, String hi_cedula, String hi_nombres, String hi_apellidos, String hi_nivelinstitucional) {
        this.id_cedula = id_cedula;
        this.hi_cedula = hi_cedula;
        this.hi_nombres = hi_nombres;
        this.hi_apellidos = hi_apellidos;
        this.hi_nivelinstitucional = hi_nivelinstitucional;
    }

    public Hijo() {
    }

    public int getIdHIJOS() {
        return idHIJOS;
    }

    public void setIdHIJOS(int idHIJOS) {
        this.idHIJOS = idHIJOS;
    }

    public int getId_cedula() {
        return id_cedula;
    }

    public void setId_cedula(int id_cedula) {
        this.id_cedula = id_cedula;
    }

    public String getHi_cedula() {
        return hi_cedula;
    }

    public void setHi_cedula(String hi_cedula) {
        this.hi_cedula = hi_cedula;
    }

    public String getHi_nombres() {
        return hi_nombres;
    }

    public void setHi_nombres(String hi_nombres) {
        this.hi_nombres = hi_nombres;
    }

    public String getHi_apellidos() {
        return hi_apellidos;
    }

    public void setHi_apellidos(String hi_apellidos) {
        this.hi_apellidos = hi_apellidos;
    }

    public String getHi_nivelinstitucional() {
        return hi_nivelinstitucional;
    }

    public void setHi_nivelinstitucional(String hi_nivelinstitucional) {
        this.hi_nivelinstitucional = hi_nivelinstitucional;
    }

    @Override
    public String toString() {
        return "hijo{" + "idHIJOS=" + idHIJOS + ", id_cedula=" + id_cedula + ", hi_cedula=" + hi_cedula + ", hi_nombres=" + hi_nombres + ", hi_apellidos=" + hi_apellidos + ", hi_nivelinstitucional=" + hi_nivelinstitucional + '}';
    }

}
