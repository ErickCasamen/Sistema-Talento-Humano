package MODELO;

public class Docente {
    private int id_cedula;
    private String doc_nombres;
    private String doc_apellidos;
    private String doc_nacionalidad;
    private String doc_fechanacimiento;
    private String doc_direccion;
    private String doc_provincia;
    private String doc_tipoetnia;
    private String doc_tipogenero;
    private String doc_estadocivil;
    private String doc_tiposangre;
    private String doc_celular;
    private String doc_telefono;
    private String doc_correo;
    private String doc_antservpublico;
    private String doc_declaracionbienes;
    private String doc_tipousuario;
    private String doc_usuario;
    private String doc_contraseña;

    public Docente(int id_cedula, String doc_nombres, String doc_apellidos, String doc_nacionalidad, String doc_fechanacimiento, String doc_direccion, String doc_provincia, String doc_tipoetnia, String doc_tipogenero, String doc_estadocivil, String doc_tiposangre, String doc_celular, String doc_telefono, String doc_correo, String doc_antservpublico, String doc_declaracionbienes, String doc_tipousuario, String doc_usuario, String doc_contraseña) {
        this.id_cedula = id_cedula;
        this.doc_nombres = doc_nombres;
        this.doc_apellidos = doc_apellidos;
        this.doc_nacionalidad = doc_nacionalidad;
        this.doc_fechanacimiento = doc_fechanacimiento;
        this.doc_direccion = doc_direccion;
        this.doc_provincia = doc_provincia;
        this.doc_tipoetnia = doc_tipoetnia;
        this.doc_tipogenero = doc_tipogenero;
        this.doc_estadocivil = doc_estadocivil;
        this.doc_tiposangre = doc_tiposangre;
        this.doc_celular = doc_celular;
        this.doc_telefono = doc_telefono;
        this.doc_correo = doc_correo;
        this.doc_antservpublico = doc_antservpublico;
        this.doc_declaracionbienes = doc_declaracionbienes;
        this.doc_tipousuario = doc_tipousuario;
        this.doc_usuario = doc_usuario;
        this.doc_contraseña = doc_contraseña;
    }

    public Docente(String doc_nombres, String doc_apellidos, String doc_nacionalidad, String doc_fechanacimiento, String doc_direccion, String doc_provincia, String doc_tipoetnia, String doc_tipogenero, String doc_estadocivil, String doc_tiposangre, String doc_celular, String doc_telefono, String doc_correo, String doc_antservpublico, String doc_declaracionbienes, String doc_tipousuario, String doc_usuario, String doc_contraseña) {
        this.doc_nombres = doc_nombres;
        this.doc_apellidos = doc_apellidos;
        this.doc_nacionalidad = doc_nacionalidad;
        this.doc_fechanacimiento = doc_fechanacimiento;
        this.doc_direccion = doc_direccion;
        this.doc_provincia = doc_provincia;
        this.doc_tipoetnia = doc_tipoetnia;
        this.doc_tipogenero = doc_tipogenero;
        this.doc_estadocivil = doc_estadocivil;
        this.doc_tiposangre = doc_tiposangre;
        this.doc_celular = doc_celular;
        this.doc_telefono = doc_telefono;
        this.doc_correo = doc_correo;
        this.doc_antservpublico = doc_antservpublico;
        this.doc_declaracionbienes = doc_declaracionbienes;
        this.doc_tipousuario = doc_tipousuario;
        this.doc_usuario = doc_usuario;
        this.doc_contraseña = doc_contraseña;
    }

    public Docente() {
    }
    

    public int getId_cedula() {
        return id_cedula;
    }

    public void setId_cedula(int id_cedula) {
        this.id_cedula = id_cedula;
    }

    public String getDoc_nombres() {
        return doc_nombres;
    }

    public void setDoc_nombres(String doc_nombres) {
        this.doc_nombres = doc_nombres;
    }

    public String getDoc_apellidos() {
        return doc_apellidos;
    }

    public void setDoc_apellidos(String doc_apellidos) {
        this.doc_apellidos = doc_apellidos;
    }

    public String getDoc_nacionalidad() {
        return doc_nacionalidad;
    }

    public void setDoc_nacionalidad(String doc_nacionalidad) {
        this.doc_nacionalidad = doc_nacionalidad;
    }

    public String getDoc_fechanacimiento() {
        return doc_fechanacimiento;
    }

    public void setDoc_fechanacimiento(String doc_fechanacimiento) {
        this.doc_fechanacimiento = doc_fechanacimiento;
    }

    public String getDoc_direccion() {
        return doc_direccion;
    }

    public void setDoc_direccion(String doc_direccion) {
        this.doc_direccion = doc_direccion;
    }

    public String getDoc_provincia() {
        return doc_provincia;
    }

    public void setDoc_provincia(String doc_provincia) {
        this.doc_provincia = doc_provincia;
    }

    public String getDoc_tipoetnia() {
        return doc_tipoetnia;
    }

    public void setDoc_tipoetnia(String doc_tipoetnia) {
        this.doc_tipoetnia = doc_tipoetnia;
    }

    public String getDoc_tipogenero() {
        return doc_tipogenero;
    }

    public void setDoc_tipogenero(String doc_tipogenero) {
        this.doc_tipogenero = doc_tipogenero;
    }

    public String getDoc_estadocivil() {
        return doc_estadocivil;
    }

    public void setDoc_estadocivil(String doc_estadocivil) {
        this.doc_estadocivil = doc_estadocivil;
    }

    public String getDoc_tiposangre() {
        return doc_tiposangre;
    }

    public void setDoc_tiposangre(String doc_tiposangre) {
        this.doc_tiposangre = doc_tiposangre;
    }

    public String getDoc_celular() {
        return doc_celular;
    }

    public void setDoc_celular(String doc_celular) {
        this.doc_celular = doc_celular;
    }

    public String getDoc_telefono() {
        return doc_telefono;
    }

    public void setDoc_telefono(String doc_telefono) {
        this.doc_telefono = doc_telefono;
    }

    public String getDoc_correo() {
        return doc_correo;
    }

    public void setDoc_correo(String doc_correo) {
        this.doc_correo = doc_correo;
    }

    public String getDoc_antservpublico() {
        return doc_antservpublico;
    }

    public void setDoc_antservpublico(String doc_antservpublico) {
        this.doc_antservpublico = doc_antservpublico;
    }

    public String getDoc_declaracionbienes() {
        return doc_declaracionbienes;
    }

    public void setDoc_declaracionbienes(String doc_declaracionbienes) {
        this.doc_declaracionbienes = doc_declaracionbienes;
    }

    public String getDoc_tipousuario() {
        return doc_tipousuario;
    }

    public void setDoc_tipousuario(String doc_tipousuario) {
        this.doc_tipousuario = doc_tipousuario;
    }

    public String getDoc_usuario() {
        return doc_usuario;
    }

    public void setDoc_usuario(String doc_usuario) {
        this.doc_usuario = doc_usuario;
    }

    public String getDoc_contraseña() {
        return doc_contraseña;
    }

    public void setDoc_contraseña(String doc_contraseña) {
        this.doc_contraseña = doc_contraseña;
    }

    @Override
    public String toString() {
        return "docente{" + "id_cedula=" + id_cedula + ", doc_nombres=" + doc_nombres + ", doc_apellidos=" + doc_apellidos + ", doc_nacionalidad=" + doc_nacionalidad + ", doc_fechanacimiento=" + doc_fechanacimiento + ", doc_direccion=" + doc_direccion + ", doc_provincia=" + doc_provincia + ", doc_tipoetnia=" + doc_tipoetnia + ", doc_tipogenero=" + doc_tipogenero + ", doc_estadocivil=" + doc_estadocivil + ", doc_tiposangre=" + doc_tiposangre + ", doc_celular=" + doc_celular + ", doc_telefono=" + doc_telefono + ", doc_correo=" + doc_correo + ", doc_antservpublico=" + doc_antservpublico + ", doc_declaracionbienes=" + doc_declaracionbienes + ", doc_tipousuario=" + doc_tipousuario + ", doc_usuario=" + doc_usuario + ", doc_contrase\u00f1a=" + doc_contraseña + '}';
    }

}
