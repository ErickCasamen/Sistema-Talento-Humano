package BD;

import java.sql.*;

public class Conexion {

    public static Connection getConexion() {
        Connection cn = null;
        String USER = "root";
        String PASSWORD = "";
        String URL = "jdbc:mysql://localhost:3306/talento_humano?autoReconnect=true&useSSL=false&useTimezone=true&serverTimezone=UTC";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            cn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("ERROR DE CONEXION: " + e.getMessage());
        }
        return cn;
    }

}
